import { useEffect } from "react";

function App() {
  useEffect(() => {
    // Redirect to the vanilla JS game
    window.location.href = "/game.html";
  }, []);

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center',
      background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)',
      color: 'white',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{ textAlign: 'center' }}>
        <h1>🌊 Loading Ocean Pollution Escape Room... 🐢</h1>
        <p>Redirecting to the educational game...</p>
      </div>
    </div>
  );
}

export default App;
