import { createRoot } from "react-dom/client";
import "./index.css";

// Redirect to the game
window.location.href = "/game.html";

createRoot(document.getElementById("root")!).render(<div>Redirecting to game...</div>);
