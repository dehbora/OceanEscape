// Main Game Controller
class OceanEscapeGame {
    constructor() {
        this.currentScreen = 'start';
        this.completedGames = new Set();
        this.totalGames = 6;
        this.gameInstances = {};
        
        this.init();
    }

    init() {
        this.loadProgress();
        this.setupEventListeners();
        this.initializeAudio();
        this.initializeLeaderboard();
        this.showScreen('start');
        this.updateProgress();
    }

    setupEventListeners() {
        // Start button
        document.getElementById('start-btn').addEventListener('click', () => {
            this.showScreen('game');
            AudioManager.playBackgroundMusic();
        });

        // Menu button
        document.getElementById('menu-btn').addEventListener('click', () => {
            this.showScreen('start');
        });

        // Leaderboard button
        document.getElementById('leaderboard-btn').addEventListener('click', () => {
            this.leaderboardModal.show();
            AudioManager.playClick();
        });

        // Sound toggle
        document.getElementById('sound-btn').addEventListener('click', () => {
            AudioManager.toggleSound();
            this.updateSoundButton();
        });

        // Zone buttons - use dedicated method
        this.attachZoneButtonListeners();

        // Back buttons
        document.querySelectorAll('.back-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const target = e.target.dataset.back || 'game';
                this.showScreen(target);
            });
        });

        // Victory screen buttons
        document.getElementById('play-again-btn').addEventListener('click', () => {
            this.resetGame();
        });

        document.getElementById('share-btn').addEventListener('click', () => {
            this.shareAchievement();
        });

        // Achievement modal
        document.getElementById('achievement-ok').addEventListener('click', () => {
            this.hideAchievement();
        });
    }

    initializeAudio() {
        AudioManager.init();
        this.updateSoundButton();
    }

    initializeLeaderboard() {
        this.leaderboardModal = new LeaderboardModal();
    }

    updateSoundButton() {
        const soundBtn = document.getElementById('sound-btn');
        const icon = soundBtn.querySelector('i');
        
        if (AudioManager.isMuted) {
            icon.className = 'fas fa-volume-mute';
            soundBtn.classList.add('muted');
        } else {
            icon.className = 'fas fa-volume-up';
            soundBtn.classList.remove('muted');
        }
    }

    showScreen(screenName) {
        // Hide all screens
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });

        // Show target screen
        const targetScreen = document.getElementById(`${screenName}-screen`);
        if (targetScreen) {
            targetScreen.classList.add('active');
            this.currentScreen = screenName;
        }

        // Handle specific screen logic
        if (screenName === 'start') {
            AudioManager.stopBackgroundMusic();
        } else if (screenName === 'game') {
            this.updateGameZones();
            AudioManager.resetMusicSettings();
        }
    }

    startMinigame(gameType) {
        console.log('=== startMinigame called ===');
        console.log('Game type:', gameType);
        console.log('Completed games:', Array.from(this.completedGames));
        
        // Initialize minigame if not already done
        if (!this.gameInstances[gameType]) {
            console.log('Initializing minigame:', gameType);
            this.initializeMinigame(gameType);
        }

        // Show minigame screen
        this.showScreen(gameType);
        
        // Set contextual audio for minigame
        AudioManager.setMinigameContext(gameType);
        AudioManager.adjustMusicForMinigame(gameType);
        
        // Start the specific minigame
        if (this.gameInstances[gameType] && this.gameInstances[gameType].start) {
            this.gameInstances[gameType].start();
        }
    }

    initializeMinigame(gameType) {
        const contentElement = document.getElementById(`${gameType}-content`);
        
        switch (gameType) {
            case 'plastic':
                this.gameInstances.plastic = new PlasticSortingGame(contentElement, this);
                break;
            case 'straw':
                this.gameInstances.straw = new StrawQuizGame(contentElement, this);
                break;
            case 'turtle':
                this.gameInstances.turtle = new TurtleRescueGame(contentElement, this);
                break;
            case 'microplastic':
                this.gameInstances.microplastic = new MicroplasticGame(contentElement, this);
                break;
            case 'oilspill':
                this.gameInstances.oilspill = new OilSpillGame(contentElement, this);
                break;
            case 'coralreef':
                this.gameInstances.coralreef = new CoralReefGame(contentElement, this);
                break;
        }
    }

    completeMinigame(gameType, achievement) {
        if (!this.completedGames.has(gameType)) {
            this.completedGames.add(gameType);
            this.saveProgress();
            this.updateProgress();
            this.showAchievement(achievement);
            
            // Save score to leaderboard if achievement has scoring data
            if (achievement.scoreData) {
                const rank = this.leaderboardModal.addNewScore(gameType, achievement.scoreData);
                console.log(`New score rank: ${rank} for ${gameType}`);
            }
            
            // Check if all games are completed
            if (this.completedGames.size >= this.totalGames) {
                setTimeout(() => {
                    this.showVictoryScreen();
                }, 2000);
            }
        }
    }

    updateProgress() {
        const progress = (this.completedGames.size / this.totalGames) * 100;
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        progressFill.style.width = `${progress}%`;
        progressText.textContent = `${this.completedGames.size}/${this.totalGames}개 미션 완료`;
    }

    updateGameZones() {
        ['plastic', 'straw', 'turtle', 'microplastic', 'oilspill', 'coralreef'].forEach(gameType => {
            const zone = document.getElementById(`zone-${gameType}`);
            const badge = document.getElementById(`badge-${gameType}`);
            const button = zone.querySelector('.zone-btn');
            
            if (this.completedGames.has(gameType)) {
                zone.classList.add('completed');
                button.innerHTML = '<i class="fas fa-check"></i> 완료';
            } else {
                zone.classList.remove('completed');
                // Reset button text based on game type
                const buttonTexts = {
                    plastic: '<i class="fas fa-play"></i> 분류 시작',
                    straw: '<i class="fas fa-play"></i> 퀴즈 시작',
                    turtle: '<i class="fas fa-play"></i> 거북이 구조',
                    microplastic: '<i class="fas fa-play"></i> 오염 측정',
                    oilspill: '<i class="fas fa-play"></i> 정화 시작',
                    coralreef: '<i class="fas fa-play"></i> 산호초 복원'
                };
                button.innerHTML = buttonTexts[gameType];
            }
        });
        // No need to re-attach - event delegation handles it
    }
    
    attachZoneButtonListeners() {
        // Event listeners now attached in inline script - do nothing here
        console.log('attachZoneButtonListeners called but skipped (inline script handles it)');
    }

    showAchievement(achievement) {
        const modal = document.getElementById('achievement-modal');
        const title = document.getElementById('achievement-title');
        const message = document.getElementById('achievement-message');
        const tip = document.getElementById('achievement-tip');
        
        title.textContent = achievement.title;
        message.innerHTML = achievement.message;
        tip.innerHTML = achievement.tip;
        
        modal.classList.add('active');
        AudioManager.playSuccess();
    }

    hideAchievement() {
        const modal = document.getElementById('achievement-modal');
        modal.classList.remove('active');
    }

    showVictoryScreen() {
        AudioManager.playSuccess();
        this.showScreen('victory');
    }

    resetGame() {
        console.log('Resetting game progress...');
        this.completedGames.clear();
        localStorage.removeItem('oceanGameProgress');
        this.saveProgress();
        this.updateProgress();
        
        // Reset all minigames
        Object.values(this.gameInstances).forEach(game => {
            if (game.reset) {
                game.reset();
            }
        });
        console.log('Game reset complete, completedGames:', this.completedGames.size);
        
        this.showScreen('start');
    }

    shareAchievement() {
        const shareText = "I just completed the Ocean Pollution Escape Room game! 🌊🐢 Join me in learning about marine conservation!";
        
        if (navigator.share) {
            navigator.share({
                title: 'Ocean Pollution Escape Room',
                text: shareText,
                url: window.location.href
            });
        } else {
            // Fallback to clipboard
            navigator.clipboard.writeText(`${shareText} ${window.location.href}`).then(() => {
                alert('Achievement shared! Link copied to clipboard.');
            });
        }
    }

    saveProgress() {
        GameStorage.saveProgress({
            completedGames: Array.from(this.completedGames),
            timestamp: Date.now()
        });
    }

    loadProgress() {
        const progress = GameStorage.loadProgress();
        if (progress && progress.completedGames) {
            this.completedGames = new Set(progress.completedGames);
        }
    }
}

// Initialize game when page loads (removed - now done inline in HTML)

// Prevent accidental page refresh
window.addEventListener('beforeunload', (e) => {
    if (window.game && window.game.currentScreen !== 'start' && window.game.currentScreen !== 'victory') {
        e.preventDefault();
        e.returnValue = '';
    }
});
