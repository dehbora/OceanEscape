// Plastic Sorting Mini-Game
class PlasticSortingGame {
    constructor(container, gameController) {
        this.container = container;
        this.gameController = gameController;
        this.isActive = false;
        this.score = 0;
        this.totalItems = 12;
        this.currentItems = [];
        this.draggedItem = null;
        
        // Initialize timer and scoring systems
        this.timer = new GameTimer(180, (time, formatted) => {
            TimerScoringUI.updateTimerDisplay('plastic-timer', time, 180);
        }, () => {
            this.timeUp();
        });
        this.scoring = new GameScoring('plastic', 100);
        this.mistakes = 0;
        this.maxMistakes = 3;
        
        this.plasticTypes = {
            'PET': { color: '#ff5722', bin: 'recyclable', name: 'PET 병' },
            'HDPE': { color: '#2196f3', bin: 'recyclable', name: 'HDPE 용기' },
            'PVC': { color: '#9c27b0', bin: 'hazardous', name: 'PVC 파이프' },
            'LDPE': { color: '#4caf50', bin: 'recyclable', name: 'LDPE 봉투' },
            'PP': { color: '#ff9800', bin: 'recyclable', name: 'PP 용기' },
            'PS': { color: '#f44336', bin: 'hazardous', name: '폴리스티렌' },
            'OTHER': { color: '#795548', bin: 'general', name: '혼합 플라스틱' },
            'BIO': { color: '#8bc34a', bin: 'compost', name: '바이오플라스틱' }
        };
        
        this.init();
    }

    init() {
        this.createGameHTML();
        this.setupEventListeners();
    }

    createGameHTML() {
        this.container.innerHTML = `
            <div class="plastic-game">
                <div class="game-info">
                    <h3>🔬 플라스틱을 올바른 통에 분류하세요!</h3>
                    <p>각 플라스틱을 적절한 재활용 통으로 드래그하세요. 플라스틱 종류마다 다른 처리 방법이 필요합니다.</p>
                    <div class="score-display">
                        <div class="score-section" id="plastic-score-section">
                            <span class="score">점수: <strong id="plastic-score">0</strong></span>
                            <div class="attempts">실수: <span id="plastic-mistakes">0</span>/${this.maxMistakes}</div>
                        </div>
                        <div class="timer-section" id="plastic-timer"></div>
                    </div>
                </div>

                <div class="recycling-bins">
                    <div class="recycling-bin" data-bin="recyclable">
                        <div class="bin-icon">♻️</div>
                        <h4>재활용 플라스틱</h4>
                        <p>PET, HDPE, LDPE, PP</p>
                        <div class="bin-area" data-bin="recyclable"></div>
                    </div>
                    
                    <div class="recycling-bin" data-bin="hazardous">
                        <div class="bin-icon">⚠️</div>
                        <h4>유해 플라스틱</h4>
                        <p>PVC, 폴리스티렌</p>
                        <div class="bin-area" data-bin="hazardous"></div>
                    </div>
                    
                    <div class="recycling-bin" data-bin="general">
                        <div class="bin-icon">🗑️</div>
                        <h4>일반 쓰레기</h4>
                        <p>혼합/미분류 플라스틱</p>
                        <div class="bin-area" data-bin="general"></div>
                    </div>
                    
                    <div class="recycling-bin" data-bin="compost">
                        <div class="bin-icon">🌱</div>
                        <h4>퇴비화 가능</h4>
                        <p>생분해성 플라스틱</p>
                        <div class="bin-area" data-bin="compost"></div>
                    </div>
                </div>

                <div class="plastic-items-area">
                    <h4>🏭 분류할 플라스틱:</h4>
                    <div class="plastic-items" id="plastic-items"></div>
                </div>

                <div class="game-controls">
                    <button id="plastic-reset" class="control-btn">🔄 게임 재시작</button>
                    <button id="plastic-hint" class="control-btn">💡 힌트 보기</button>
                </div>

                <div class="educational-info">
                    <h4>📚 교육 정보:</h4>
                    <div class="info-grid">
                        <div class="info-card">
                            <strong>♻️ 재활용 플라스틱</strong>
                            <p>새로운 제품으로 재가공 가능합니다. 재활용 전 용기를 깨끗이 씻어주세요!</p>
                        </div>
                        <div class="info-card">
                            <strong>⚠️ 유해 플라스틱</strong>
                            <p>유해 화학물질을 포함하며 특별한 처리 방법이 필요합니다.</p>
                        </div>
                        <div class="info-card">
                            <strong>🌱 바이오플라스틱</strong>
                            <p>재생 가능한 자원으로 만들어지며 퇴비화가 가능합니다.</p>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .plastic-game {
                    max-width: 1000px;
                    margin: 0 auto;
                }

                .game-info {
                    text-align: center;
                    margin-bottom: 2rem;
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .score-display {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-top: 1rem;
                    padding: 1rem;
                    background: rgba(0, 188, 212, 0.2);
                    border-radius: 8px;
                }

                .recycling-bins {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                    margin-bottom: 2rem;
                }

                .recycling-bin {
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                    padding: 1rem;
                    text-align: center;
                    border: 2px solid rgba(255, 255, 255, 0.2);
                    transition: all 0.3s ease;
                }

                .recycling-bin:hover {
                    border-color: #4fc3f7;
                    background: rgba(79, 195, 247, 0.1);
                }

                .bin-icon {
                    font-size: 2rem;
                    margin-bottom: 0.5rem;
                }

                .bin-area {
                    min-height: 80px;
                    border: 2px dashed rgba(255, 255, 255, 0.3);
                    border-radius: 8px;
                    margin-top: 1rem;
                    padding: 0.5rem;
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    justify-content: center;
                    align-items: center;
                }

                .bin-area.drag-over {
                    border-color: #4fc3f7;
                    background: rgba(79, 195, 247, 0.2);
                }

                .plastic-items-area {
                    margin-bottom: 2rem;
                }

                .plastic-items {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 1rem;
                    justify-content: center;
                    padding: 1rem;
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 10px;
                    min-height: 120px;
                }

                .plastic-item {
                    width: 80px;
                    height: 80px;
                    border-radius: 10px;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    cursor: grab;
                    transition: all 0.3s ease;
                    border: 2px solid rgba(255, 255, 255, 0.3);
                    color: white;
                    font-weight: bold;
                    font-size: 0.8rem;
                    text-align: center;
                    user-select: none;
                    position: relative;
                }

                .plastic-item:hover {
                    transform: scale(1.05);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                }

                .plastic-item.dragging {
                    cursor: grabbing;
                    transform: scale(1.1);
                    z-index: 1000;
                    opacity: 0.8;
                }

                .plastic-item.placed {
                    cursor: default;
                    opacity: 0.7;
                    transform: scale(0.8);
                }

                .game-controls {
                    display: flex;
                    gap: 1rem;
                    justify-content: center;
                    margin-bottom: 2rem;
                }

                .control-btn {
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border: none;
                    padding: 10px 20px;
                    border-radius: 20px;
                    color: white;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .control-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(0, 188, 212, 0.4);
                }

                .educational-info {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                }

                .info-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 1rem;
                    margin-top: 1rem;
                }

                .info-card {
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    border-left: 4px solid #4fc3f7;
                }

                .feedback-message {
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: rgba(0, 0, 0, 0.9);
                    color: white;
                    padding: 1rem 2rem;
                    border-radius: 10px;
                    z-index: 2000;
                    font-size: 1.2rem;
                    animation: fadeInOut 2s ease-in-out;
                }

                @keyframes fadeInOut {
                    0%, 100% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
                    20%, 80% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                }

                .feedback-message.correct {
                    background: rgba(76, 175, 80, 0.9);
                }

                .feedback-message.incorrect {
                    background: rgba(244, 67, 54, 0.9);
                }

                @media (max-width: 768px) {
                    .recycling-bins {
                        grid-template-columns: repeat(2, 1fr);
                    }
                    
                    .plastic-items {
                        gap: 0.5rem;
                    }
                    
                    .plastic-item {
                        width: 60px;
                        height: 60px;
                        font-size: 0.7rem;
                    }

                    .game-controls {
                        flex-direction: column;
                        align-items: center;
                    }

                    .info-grid {
                        grid-template-columns: 1fr;
                    }
                }
            </style>
        `;
    }

    setupEventListeners() {
        // Reset button
        document.getElementById('plastic-reset').addEventListener('click', () => {
            this.reset();
        });

        // Hint button
        document.getElementById('plastic-hint').addEventListener('click', () => {
            this.showHint();
        });
    }

    start() {
        this.isActive = true;
        this.score = 0;
        this.mistakes = 0;
        
        // Initialize timer display and start timer
        TimerScoringUI.createTimerDisplay('plastic-timer', 'Time Remaining');
        this.timer.reset();
        this.timer.start();
        
        // Reset scoring
        this.scoring = new GameScoring('plastic', 100);
        
        this.generatePlasticItems();
        this.updateScore();
    }

    generatePlasticItems() {
        const itemsContainer = document.getElementById('plastic-items');
        itemsContainer.innerHTML = '';
        this.currentItems = [];

        // Create a balanced mix of plastic types
        const plasticKeys = Object.keys(this.plasticTypes);
        for (let i = 0; i < this.totalItems; i++) {
            const type = plasticKeys[i % plasticKeys.length];
            const plastic = this.plasticTypes[type];
            
            const item = {
                id: `item-${i}`,
                type: type,
                correctBin: plastic.bin,
                name: plastic.name,
                color: plastic.color
            };
            
            this.currentItems.push(item);
            this.createPlasticElement(item, itemsContainer);
        }

        // Shuffle the items
        this.shuffleItems();
    }

    createPlasticElement(item, container) {
        const element = document.createElement('div');
        element.className = 'plastic-item';
        element.id = item.id;
        element.style.backgroundColor = item.color;
        element.draggable = true;
        element.innerHTML = `
            <div style="font-size: 0.9rem; margin-bottom: 0.2rem;">${item.type}</div>
            <div style="font-size: 0.6rem; opacity: 0.9;">${item.name.split(' ')[0]}</div>
        `;

        // Add drag event listeners
        element.addEventListener('dragstart', this.handleDragStart.bind(this));
        element.addEventListener('dragend', this.handleDragEnd.bind(this));

        // Add touch support for mobile
        element.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: false });
        element.addEventListener('touchmove', this.handleTouchMove.bind(this), { passive: false });
        element.addEventListener('touchend', this.handleTouchEnd.bind(this), { passive: false });

        container.appendChild(element);

        // Setup drop zones
        this.setupDropZones();
    }

    setupDropZones() {
        document.querySelectorAll('.bin-area').forEach(bin => {
            bin.addEventListener('dragover', this.handleDragOver.bind(this));
            bin.addEventListener('drop', this.handleDrop.bind(this));
            bin.addEventListener('dragenter', this.handleDragEnter.bind(this));
            bin.addEventListener('dragleave', this.handleDragLeave.bind(this));
        });
    }

    handleDragStart(e) {
        this.draggedItem = e.target;
        e.target.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', e.target.outerHTML);
    }

    handleDragEnd(e) {
        e.target.classList.remove('dragging');
        document.querySelectorAll('.bin-area').forEach(bin => {
            bin.classList.remove('drag-over');
        });
    }

    handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }

    handleDragEnter(e) {
        e.preventDefault();
        e.target.classList.add('drag-over');
    }

    handleDragLeave(e) {
        e.target.classList.remove('drag-over');
    }

    handleDrop(e) {
        e.preventDefault();
        e.target.classList.remove('drag-over');
        
        if (this.draggedItem) {
            const binType = e.target.dataset.bin;
            const itemId = this.draggedItem.id;
            const item = this.currentItems.find(i => i.id === itemId);
            
            if (item) {
                this.checkPlacement(item, binType, e.target);
            }
        }
    }

    // Touch event handlers for mobile support
    handleTouchStart(e) {
        e.preventDefault();
        this.draggedItem = e.target;
        e.target.classList.add('dragging');
        
        this.touchOffset = {
            x: e.touches[0].clientX - e.target.offsetLeft,
            y: e.touches[0].clientY - e.target.offsetTop
        };
    }

    handleTouchMove(e) {
        e.preventDefault();
        if (this.draggedItem) {
            const touch = e.touches[0];
            this.draggedItem.style.position = 'fixed';
            this.draggedItem.style.left = (touch.clientX - this.touchOffset.x) + 'px';
            this.draggedItem.style.top = (touch.clientY - this.touchOffset.y) + 'px';
            this.draggedItem.style.zIndex = '1000';
            
            // Highlight drop zones
            const elementBelow = document.elementFromPoint(touch.clientX, touch.clientY);
            document.querySelectorAll('.bin-area').forEach(bin => {
                bin.classList.remove('drag-over');
            });
            
            if (elementBelow && elementBelow.classList.contains('bin-area')) {
                elementBelow.classList.add('drag-over');
            }
        }
    }

    handleTouchEnd(e) {
        e.preventDefault();
        if (this.draggedItem) {
            const touch = e.changedTouches[0];
            const elementBelow = document.elementFromPoint(touch.clientX, touch.clientY);
            
            if (elementBelow && elementBelow.classList.contains('bin-area')) {
                const binType = elementBelow.dataset.bin;
                const itemId = this.draggedItem.id;
                const item = this.currentItems.find(i => i.id === itemId);
                
                if (item) {
                    this.checkPlacement(item, binType, elementBelow);
                }
            }
            
            // Reset styles
            this.draggedItem.style.position = '';
            this.draggedItem.style.left = '';
            this.draggedItem.style.top = '';
            this.draggedItem.style.zIndex = '';
            this.draggedItem.classList.remove('dragging');
            
            document.querySelectorAll('.bin-area').forEach(bin => {
                bin.classList.remove('drag-over');
            });
        }
        
        this.draggedItem = null;
    }

    checkPlacement(item, binType, binElement) {
        const isCorrect = item.correctBin === binType;
        
        if (isCorrect) {
            // Correct placement
            this.score++;
            const points = this.scoring.addPoints(100, true);
            this.showFeedback('정답! ' + item.name + '은(는) ' + binType + ' 통에 넣어야 합니다! ✅ (+' + points + ' 점)', 'correct');
            
            // Move item to bin and mark as placed
            const itemElement = document.getElementById(item.id);
            itemElement.classList.add('placed');
            binElement.appendChild(itemElement);
            
            AudioManager.playPlasticSort();
            
        } else {
            // Incorrect placement
            this.mistakes++;
            const penalty = this.scoring.addPoints(100, false);
            this.showFeedback('오답! ' + item.name + '은(는) ' + item.correctBin + ' 통에 넣어야 합니다! ❌ (' + penalty + ' 점)', 'incorrect');
            
            // Check if too many mistakes
            if (this.mistakes >= this.maxMistakes) {
                this.timeUp(); // Use timeUp method for consistent handling
                return;
            }
        }
        
        this.updateScore();
        
        // Check if game is complete
        if (this.score >= this.totalItems) {
            setTimeout(() => this.completeGame(), 1000);
        }
    }

    showFeedback(message, type) {
        const feedback = document.createElement('div');
        feedback.className = `feedback-message ${type}`;
        feedback.textContent = message;
        
        document.body.appendChild(feedback);
        
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.parentNode.removeChild(feedback);
            }
        }, 2000);
    }

    showHint() {
        const remainingItems = this.currentItems.filter(item => 
            !document.getElementById(item.id).classList.contains('placed')
        );
        
        if (remainingItems.length > 0) {
            const randomItem = remainingItems[Math.floor(Math.random() * remainingItems.length)];
            this.showFeedback(`힌트: ${randomItem.name}은(는) ${randomItem.correctBin} 통에 넣어야 합니다! 💡`, 'correct');
        }
    }

    shuffleItems() {
        const container = document.getElementById('plastic-items');
        const items = Array.from(container.children);
        
        // Shuffle array
        for (let i = items.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [items[i], items[j]] = [items[j], items[i]];
        }
        
        // Re-append in new order
        items.forEach(item => container.appendChild(item));
    }

    updateScore() {
        document.getElementById('plastic-score').textContent = this.scoring.score.toLocaleString();
        document.getElementById('plastic-mistakes').textContent = this.mistakes;
        
        // Update score display with streak information
        TimerScoringUI.updateScoreDisplay('plastic-score-section', this.scoring.score, this.scoring.streakCount);
    }

    completeGame() {
        this.timer.stop();
        this.isActive = false;
        
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '♻️ 플라스틱 분류 전문가!',
            message: `<p>훌륭합니다! 모든 플라스틱을 올바른 통에 분류했습니다.</p>
                     <div class="score-summary">
                         <p><strong>최종 점수:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>정확도:</strong> ${stats.accuracy}%</p>
                         <p><strong>등급:</strong> ${stats.grade}</p>
                         <p><strong>시간:</strong> ${this.timer.getFormattedTime()}</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>🌍 환경 영향:</strong><br>올바른 플라스틱 분류는 재활용률을 최대 60%까지 높이고 해양 오염을 크게 줄일 수 있습니다!</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: stats.perfectGame,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('plastic', achievement);
    }
    
    timeUp() {
        this.isActive = false;
        this.timer.stop();
        
        // Calculate partial completion score
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '⏰ 시간 종료!',
            message: `<p>시간이 다 됐지만, 플라스틱 분류를 잘 진행했습니다!</p>
                     <div class="score-summary">
                         <p><strong>점수:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>분류한 항목:</strong> ${this.score}/${this.totalItems}</p>
                         <p><strong>정확도:</strong> ${stats.accuracy}%</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>⚡ 팁:</strong><br>연습이 완벽을 만듭니다! 정확도를 유지하면서 더 빠르게 분류하면 높은 점수를 얻을 수 있습니다.</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: false,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('plastic', achievement);
    }

    reset() {
        this.score = 0;
        this.mistakes = 0;
        this.start();
    }
}
