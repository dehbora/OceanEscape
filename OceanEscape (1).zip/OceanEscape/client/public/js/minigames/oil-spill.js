// Oil Spill Cleanup Mini-Game
class OilSpillGame {
    constructor(container, gameController) {
        this.container = container;
        this.gameController = gameController;
        this.isActive = false;
        this.score = 0;
        this.spillsCleaned = 0;
        this.totalSpills = 8;
        this.activeTool = null;
        this.currentSpills = [];
        this.toolEfficiency = 100;
        
        // Initialize timer and scoring systems
        this.timer = new GameTimer(210, (time, formatted) => {
            TimerScoringUI.updateTimerDisplay('oil-timer', time, 210);
        }, () => {
            this.timeUp();
        });
        this.scoring = new GameScoring('oilspill', 125);
        this.mistakes = 0;
        this.maxMistakes = 3;
        
        // Define cleanup tools and their properties
        this.cleanupTools = {
            'skimmer': {
                name: '기름 스키머',
                icon: '🧽',
                effectiveness: { light: 90, medium: 70, heavy: 40 },
                speed: 'fast',
                description: '수면의 기름 제거'
            },
            'boom': {
                name: '차단막',
                icon: '🚧',
                effectiveness: { light: 50, medium: 85, heavy: 95 },
                speed: 'slow',
                description: '기름 확산 억제 및 제어'
            },
            'dispersant': {
                name: '분산제',
                icon: '💨',
                effectiveness: { light: 80, medium: 60, heavy: 30 },
                speed: 'instant',
                description: '기름을 작은 방울로 분해'
            },
            'absorbent': {
                name: '흡착 패드',
                icon: '🧻',
                effectiveness: { light: 95, medium: 50, heavy: 20 },
                speed: 'fast',
                description: '표면의 기름 흡수'
            }
        };
        
        // Define oil spill types
        this.spillTypes = {
            'light': { color: '#8D6E63', opacity: 0.6, size: 'small', name: '경질유' },
            'medium': { color: '#5D4037', opacity: 0.8, size: 'medium', name: '중질유' },
            'heavy': { color: '#3E2723', opacity: 0.9, size: 'large', name: '중유' }
        };
        
        this.init();
    }

    init() {
        this.createGameHTML();
        this.setupEventListeners();
    }

    createGameHTML() {
        this.container.innerHTML = `
            <div class="oil-spill-game">
                <div class="game-info">
                    <h3>🛢️ 기름 유출 비상 대응</h3>
                    <p>각 유형의 기름 유출에 적합한 정화 도구를 선택하세요. 중질유에는 차단막, 표면 기름에는 스키머를 사용하세요.</p>
                    <div class="game-stats">
                        <div class="score-section" id="oil-score-section">
                            <span class="score">점수: <strong id="oil-score">0</strong></span>
                            <div class="attempts">실수: <span id="oil-mistakes">0</span>/${this.maxMistakes}</div>
                        </div>
                        <div class="timer-section" id="oil-timer"></div>
                        <div class="progress-section">
                            정화한 유출: <span id="spills-cleaned">0</span>/${this.totalSpills}
                        </div>
                    </div>
                </div>

                <div class="cleanup-tools">
                    <h4>🛠️ 정화 도구</h4>
                    <div class="tools-grid">
                        <div class="tool-card" data-tool="skimmer">
                            <div class="tool-icon">🧽</div>
                            <div class="tool-name">기름 스키머</div>
                            <div class="tool-info">최적: 경질유</div>
                        </div>
                        <div class="tool-card" data-tool="boom">
                            <div class="tool-icon">🚧</div>
                            <div class="tool-name">차단막</div>
                            <div class="tool-info">최적: 중유</div>
                        </div>
                        <div class="tool-card" data-tool="dispersant">
                            <div class="tool-icon">💨</div>
                            <div class="tool-name">분산제</div>
                            <div class="tool-info">최적: 경질-중질유</div>
                        </div>
                        <div class="tool-card" data-tool="absorbent">
                            <div class="tool-icon">🧻</div>
                            <div class="tool-name">흡착 패드</div>
                            <div class="tool-info">최적: 표면 정화</div>
                        </div>
                    </div>
                    <div class="tool-selection">
                        <span id="selected-tool">위에서 정화 도구를 선택하세요</span>
                    </div>
                </div>

                <div class="ocean-area" id="ocean-area">
                    <div class="ocean-background">
                        <div class="wave wave-1"></div>
                        <div class="wave wave-2"></div>
                        <div class="wave wave-3"></div>
                    </div>
                    <div class="spill-container" id="spill-container">
                        <!-- Oil spills will be dynamically added here -->
                    </div>
                    <div class="marine-life">
                        <div class="marine-animal" style="left: 10%; top: 60%;">🐟</div>
                        <div class="marine-animal" style="left: 80%; top: 40%;">🦭</div>
                        <div class="marine-animal" style="left: 50%; top: 80%;">🐙</div>
                        <div class="marine-animal" style="left: 25%; top: 30%;">🦈</div>
                    </div>
                </div>

                <div class="game-controls">
                    <button id="start-cleanup" class="control-btn">🚀 정화 시작</button>
                    <button id="reset-cleanup" class="control-btn">🔄 재시작</button>
                    <button id="hint-cleanup" class="control-btn">💡 힌트</button>
                </div>

                <div class="educational-content">
                    <h4>🌊 기름 유출 대응 사실</h4>
                    <div class="facts-grid">
                        <div class="fact-card">
                            <strong>⚡ 대응 시간</strong>
                            <p>처음 24-48시간이 기름 유출 대응에 매우 중요합니다. 신속한 조치로 환경 피해의 80%를 예방할 수 있습니다.</p>
                        </div>
                        <div class="fact-card">
                            <strong>🛠️ 도구 선택</strong>
                            <p>기름 유형에 따라 다른 정화 방법이 필요합니다. 중유는 차단이, 경질유는 스키밍이 필요합니다.</p>
                        </div>
                        <div class="fact-card">
                            <strong>🐟 야생 동물 영향</strong>
                            <p>기름 유출은 해양 동물의 체온 조절 능력에 영향을 미치고 장기적인 건강 문제를 일으킬 수 있습니다.</p>
                        </div>
                        <div class="fact-card">
                            <strong>🌱 회복 시간</strong>
                            <p>생태계는 대규모 기름 유출에서 완전히 회복하는 데 5-10년이 걸리며, 일부 영향은 수십 년 지속됩니다.</p>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .oil-spill-game {
                    max-width: 1200px;
                    margin: 0 auto;
                }

                .game-info {
                    text-align: center;
                    margin-bottom: 2rem;
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .game-stats {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-top: 1rem;
                    gap: 1rem;
                    flex-wrap: wrap;
                }

                .cleanup-tools {
                    margin-bottom: 2rem;
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .tools-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                    margin: 1rem 0;
                }

                .tool-card {
                    background: rgba(255, 255, 255, 0.1);
                    border: 2px solid rgba(255, 255, 255, 0.3);
                    border-radius: 10px;
                    padding: 1rem;
                    text-align: center;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .tool-card:hover {
                    background: rgba(79, 195, 247, 0.2);
                    border-color: #4fc3f7;
                    transform: translateY(-2px);
                }

                .tool-card.selected {
                    background: rgba(79, 195, 247, 0.3);
                    border-color: #4fc3f7;
                    box-shadow: 0 0 15px rgba(79, 195, 247, 0.5);
                }

                .tool-icon {
                    font-size: 2rem;
                    margin-bottom: 0.5rem;
                }

                .tool-name {
                    font-weight: bold;
                    margin-bottom: 0.5rem;
                }

                .tool-info {
                    font-size: 0.9rem;
                    opacity: 0.8;
                }

                .tool-selection {
                    text-align: center;
                    padding: 0.5rem;
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 5px;
                    margin-top: 1rem;
                }

                .ocean-area {
                    position: relative;
                    height: 400px;
                    background: linear-gradient(180deg, #81D4FA 0%, #0277BD 100%);
                    border-radius: 15px;
                    overflow: hidden;
                    margin-bottom: 2rem;
                    border: 3px solid rgba(255, 255, 255, 0.3);
                }

                .ocean-background {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                }

                .wave {
                    position: absolute;
                    background: rgba(255, 255, 255, 0.1);
                    height: 20px;
                    border-radius: 50px;
                    animation: wave-movement 6s infinite linear;
                }

                .wave-1 {
                    width: 200px;
                    top: 20%;
                    animation-delay: 0s;
                }

                .wave-2 {
                    width: 150px;
                    top: 40%;
                    animation-delay: 2s;
                }

                .wave-3 {
                    width: 180px;
                    top: 60%;
                    animation-delay: 4s;
                }

                @keyframes wave-movement {
                    0% { left: -200px; }
                    100% { left: 100%; }
                }

                .spill-container {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                }

                .oil-spill {
                    position: absolute;
                    border-radius: 50%;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    border: 2px solid rgba(0, 0, 0, 0.2);
                }

                .oil-spill:hover {
                    transform: scale(1.1);
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
                }

                .oil-spill.small {
                    width: 60px;
                    height: 60px;
                }

                .oil-spill.medium {
                    width: 80px;
                    height: 80px;
                }

                .oil-spill.large {
                    width: 100px;
                    height: 100px;
                }

                .oil-spill.cleaning {
                    animation: cleanup-animation 2s ease-in-out;
                }

                @keyframes cleanup-animation {
                    0% { opacity: 1; transform: scale(1); }
                    50% { opacity: 0.5; transform: scale(1.2); }
                    100% { opacity: 0; transform: scale(0); }
                }

                .marine-life {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                    pointer-events: none;
                }

                .marine-animal {
                    position: absolute;
                    font-size: 1.5rem;
                    animation: swim 8s infinite linear;
                }

                @keyframes swim {
                    0%, 100% { transform: translateX(0) scaleX(1); }
                    50% { transform: translateX(20px) scaleX(-1); }
                }

                .game-controls {
                    display: flex;
                    justify-content: center;
                    gap: 1rem;
                    margin-bottom: 2rem;
                    flex-wrap: wrap;
                }

                .control-btn {
                    background: rgba(79, 195, 247, 0.2);
                    border: 2px solid #4fc3f7;
                    color: white;
                    padding: 0.75rem 1.5rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: bold;
                    transition: all 0.3s ease;
                }

                .control-btn:hover {
                    background: rgba(79, 195, 247, 0.3);
                    transform: translateY(-2px);
                }

                .educational-content {
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .facts-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 1rem;
                    margin-top: 1rem;
                }

                .fact-card {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    border-left: 4px solid #4fc3f7;
                }

                .feedback-message {
                    position: fixed;
                    top: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    font-weight: bold;
                    z-index: 1000;
                    animation: slide-down 0.5s ease-out;
                }

                .feedback-message.correct {
                    background: rgba(76, 175, 80, 0.9);
                    color: white;
                }

                .feedback-message.incorrect {
                    background: rgba(244, 67, 54, 0.9);
                    color: white;
                }

                @keyframes slide-down {
                    from { transform: translateX(-50%) translateY(-100%); }
                    to { transform: translateX(-50%) translateY(0); }
                }

                @media (max-width: 768px) {
                    .tools-grid {
                        grid-template-columns: repeat(2, 1fr);
                    }
                    
                    .game-stats {
                        flex-direction: column;
                        text-align: center;
                    }
                    
                    .ocean-area {
                        height: 300px;
                    }
                    
                    .facts-grid {
                        grid-template-columns: 1fr;
                    }
                }
            </style>
        `;
    }

    setupEventListeners() {
        // Tool selection
        document.querySelectorAll('.tool-card').forEach(card => {
            card.addEventListener('click', (e) => {
                this.selectTool(e.currentTarget.dataset.tool);
            });
        });

        // Game controls
        document.getElementById('start-cleanup').addEventListener('click', () => {
            this.start();
        });

        document.getElementById('reset-cleanup').addEventListener('click', () => {
            this.reset();
        });

        document.getElementById('hint-cleanup').addEventListener('click', () => {
            this.showHint();
        });
    }

    selectTool(toolType) {
        if (!this.isActive) return;

        this.activeTool = toolType;
        const tool = this.cleanupTools[toolType];
        
        // Update UI
        document.querySelectorAll('.tool-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.querySelector(`[data-tool="${toolType}"]`).classList.add('selected');
        
        document.getElementById('selected-tool').textContent = 
            `Selected: ${tool.name} - ${tool.description}`;
        
        AudioManager.playSound('click');
    }

    start() {
        this.isActive = true;
        this.score = 0;
        this.spillsCleaned = 0;
        this.mistakes = 0;
        this.activeTool = null;
        
        // Initialize timer display and start timer
        TimerScoringUI.createTimerDisplay('oil-timer', 'Time Remaining');
        TimerScoringUI.createScoreDisplay('oil-score-section', 0);
        this.timer.reset();
        this.timer.start();
        
        // Reset scoring
        this.scoring = new GameScoring('oilspill', 125);
        
        this.generateOilSpills();
        this.updateStats();
        
        // Reset tool selection
        document.querySelectorAll('.tool-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.getElementById('selected-tool').textContent = 'Select a cleanup tool above';
    }

    generateOilSpills() {
        const spillContainer = document.getElementById('spill-container');
        spillContainer.innerHTML = '';
        this.currentSpills = [];

        const spillTypes = ['light', 'medium', 'heavy'];
        
        for (let i = 0; i < this.totalSpills; i++) {
            const spillType = spillTypes[Math.floor(Math.random() * spillTypes.length)];
            const spill = {
                id: `spill-${i}`,
                type: spillType,
                cleaned: false,
                x: 10 + Math.random() * 70, // 10% to 80% of container width
                y: 10 + Math.random() * 70  // 10% to 80% of container height
            };
            
            this.currentSpills.push(spill);
            this.createSpillElement(spill, spillContainer);
        }
    }

    createSpillElement(spill, container) {
        const spillData = this.spillTypes[spill.type];
        const element = document.createElement('div');
        element.className = `oil-spill ${spillData.size}`;
        element.id = spill.id;
        element.style.left = `${spill.x}%`;
        element.style.top = `${spill.y}%`;
        element.style.backgroundColor = spillData.color;
        element.style.opacity = spillData.opacity;
        
        element.addEventListener('click', () => {
            this.cleanSpill(spill);
        });

        container.appendChild(element);
    }

    cleanSpill(spill) {
        if (!this.isActive || spill.cleaned || !this.activeTool) {
            if (!this.activeTool) {
                this.showFeedback('Select a cleanup tool first! 🛠️', 'incorrect');
            }
            return;
        }

        const tool = this.cleanupTools[this.activeTool];
        const effectiveness = tool.effectiveness[spill.type];
        const spillElement = document.getElementById(spill.id);
        
        // Check if tool is appropriate (>60% effectiveness)
        const isEffective = effectiveness >= 60;
        
        if (isEffective) {
            // Successful cleanup
            const points = this.scoring.addPoints(effectiveness, true);
            this.spillsCleaned++;
            spill.cleaned = true;
            
            this.showFeedback(
                `훌륭한 선택! ${tool.name}은(는) ${spill.type}에 ${effectiveness}% 효과적입니다! (+${points} 점)`, 
                'correct'
            );
            
            // Animate cleanup
            spillElement.classList.add('cleaning');
            AudioManager.playSound('success');
            
            setTimeout(() => {
                spillElement.remove();
            }, 2000);
            
        } else {
            // Poor tool choice
            this.mistakes++;
            const penalty = this.scoring.addPoints(50, false);
            
            this.showFeedback(
                `좋지 않은 선택! ${tool.name}은(는) ${spill.type}에 ${effectiveness}% 효과만 있습니다. (${penalty} 점)`, 
                'incorrect'
            );
            
            // Check if too many mistakes
            if (this.mistakes >= this.maxMistakes) {
                this.timeUp();
                return;
            }
        }
        
        this.updateStats();
        
        // Check if all spills are cleaned
        if (this.spillsCleaned >= this.totalSpills) {
            setTimeout(() => this.completeGame(), 1000);
        }
    }

    showFeedback(message, type) {
        const feedback = document.createElement('div');
        feedback.className = `feedback-message ${type}`;
        feedback.textContent = message;
        
        document.body.appendChild(feedback);
        
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.parentNode.removeChild(feedback);
            }
        }, 3000);
    }

    showHint() {
        if (!this.isActive) return;
        
        const remainingSpills = this.currentSpills.filter(spill => !spill.cleaned);
        if (remainingSpills.length === 0) return;
        
        const randomSpill = remainingSpills[Math.floor(Math.random() * remainingSpills.length)];
        const bestTool = this.getBestTool(randomSpill.type);
        
        this.showFeedback(
            `💡 힌트: ${randomSpill.type} 기름 유출에는 ${bestTool.name}을(를) 사용하세요!`, 
            'correct'
        );
    }

    getBestTool(spillType) {
        let bestTool = null;
        let bestEffectiveness = 0;
        
        Object.entries(this.cleanupTools).forEach(([toolType, tool]) => {
            if (tool.effectiveness[spillType] > bestEffectiveness) {
                bestEffectiveness = tool.effectiveness[spillType];
                bestTool = tool;
            }
        });
        
        return bestTool;
    }

    updateStats() {
        document.getElementById('oil-score').textContent = this.scoring.score.toLocaleString();
        document.getElementById('oil-mistakes').textContent = this.mistakes;
        document.getElementById('spills-cleaned').textContent = this.spillsCleaned;
        
        TimerScoringUI.updateScoreDisplay('oil-score-section', this.scoring.score, this.scoring.streakCount);
    }

    completeGame() {
        this.timer.stop();
        this.isActive = false;
        
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '🛢️ 기름 유출 대응 전문가!',
            message: `<p>훌륭한 작업입니다! 모든 기름 유출을 성공적으로 정화하고 해양 생물을 보호했습니다.</p>
                     <div class="score-summary">
                         <p><strong>최종 점수:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>정확도:</strong> ${stats.accuracy}%</p>
                         <p><strong>등급:</strong> ${stats.grade}</p>
                         <p><strong>대응 시간:</strong> ${this.timer.getFormattedTime()}</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>🌊 환경 영향:</strong><br>신속하고 효과적인 기름 유출 대응으로 수천 마리의 해양 동물을 구하고 장기적인 생태계 피해를 방지할 수 있습니다. 모든 초가 중요합니다!</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: stats.perfectGame,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('oilspill', achievement);
    }

    timeUp() {
        this.isActive = false;
        this.timer.stop();
        
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '⏰ 비상 대응 완료!',
            message: `<p>시간 종료! ${this.totalSpills}개 중 ${this.spillsCleaned}개의 기름 유출을 정화했습니다.</p>
                     <div class="score-summary">
                         <p><strong>점수:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>정화한 유출:</strong> ${this.spillsCleaned}/${this.totalSpills}</p>
                         <p><strong>정확도:</strong> ${stats.accuracy}%</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>⚡ 대응 팁:</strong><br>실제 비상 상황에서는 올바른 정화 도구를 빠르게 선택하는 것이 중요합니다. 연습이 완벽을 만듭니다!</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: false,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('oilspill', achievement);
    }

    reset() {
        this.isActive = false;
        this.timer.stop();
        this.score = 0;
        this.spillsCleaned = 0;
        this.mistakes = 0;
        this.activeTool = null;
        this.scoring = new GameScoring('oilspill', 125);
        
        // Clear spills
        document.getElementById('spill-container').innerHTML = '';
        
        // Reset UI
        document.querySelectorAll('.tool-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.getElementById('selected-tool').textContent = 'Select a cleanup tool above';
        
        this.updateStats();
    }
}

// Make the class available globally
window.OilSpillGame = OilSpillGame;