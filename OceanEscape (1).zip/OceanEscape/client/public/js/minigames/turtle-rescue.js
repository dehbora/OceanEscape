// Sea Turtle Rescue Mini-Game
class TurtleRescueGame {
    constructor(container, gameController) {
        this.container = container;
        this.gameController = gameController;
        this.isActive = false;
        this.score = 0;
        this.turtlesSaved = 0;
        this.totalTurtles = 8;
        this.timeRemaining = 120; // 2 minutes
        this.gameTimer = null;
        this.turtles = [];
        this.threats = [];
        
        this.init();
    }

    init() {
        this.createGameHTML();
        this.setupEventListeners();
    }

    createGameHTML() {
        this.container.innerHTML = `
            <div class="turtle-rescue">
                <div class="game-info">
                    <h3>🐢 바다거북 구조 작전</h3>
                    <p>어망, 비닐봉지 및 기타 쓰레기를 클릭하여 제거하고 바다거북을 구하세요! 시간이 다 되기 전에 8마리 모두를 구출하세요.</p>
                    <div class="game-stats">
                        <div class="stat">
                            <div class="stat-label">구조한 거북이</div>
                            <div class="stat-value" id="turtles-saved">0/${this.totalTurtles}</div>
                        </div>
                        <div class="stat">
                            <div class="stat-label">점수</div>
                            <div class="stat-value" id="rescue-score">0</div>
                        </div>
                        <div class="stat">
                            <div class="stat-label">시간</div>
                            <div class="stat-value" id="time-remaining">2:00</div>
                        </div>
                    </div>
                </div>

                <div class="ocean-scene" id="ocean-scene">
                    <div class="water-effect"></div>
                    <div class="coral-reef">
                        <div class="coral coral-1">🪸</div>
                        <div class="coral coral-2">🪸</div>
                        <div class="coral coral-3">🌿</div>
                        <div class="coral coral-4">🌿</div>
                    </div>
                    
                    <!-- Turtles and threats will be dynamically added here -->
                </div>

                <div class="rescue-instructions">
                    <h4>🚨 구조 방법:</h4>
                    <div class="instruction-grid">
                        <div class="instruction">
                            <span class="threat-icon">🎣</span>
                            <strong>어망</strong>
                            <p>클릭하여 그물을 자르고 갇힌 거북이를 풀어주세요</p>
                        </div>
                        <div class="instruction">
                            <span class="threat-icon">🛍️</span>
                            <strong>비닐봉지</strong>
                            <p>거북이가 해파리로 착각하는 비닐봉지를 제거하세요</p>
                        </div>
                        <div class="instruction">
                            <span class="threat-icon">🥤</span>
                            <strong>플라스틱 쓰레기</strong>
                            <p>빨대 및 기타 플라스틱 쓰레기를 제거하세요</p>
                        </div>
                        <div class="instruction">
                            <span class="threat-icon">🛢️</span>
                            <strong>기름 유출</strong>
                            <p>기름 오염을 제거하여 거북이가 숨쉴 수 있게 하세요</p>
                        </div>
                    </div>
                </div>

                <div class="game-controls">
                    <button id="start-rescue" class="control-btn">🚀 구조 시작</button>
                    <button id="reset-rescue" class="control-btn">🔄 재시작</button>
                    <button id="pause-rescue" class="control-btn">⏸️ 일시정지</button>
                </div>

                <div class="educational-facts">
                    <h4>🧠 알고 계셨나요?</h4>
                    <div class="facts-container" id="facts-container">
                        <div class="fact-card active">
                            <strong>🌊 해양 오염의 영향</strong>
                            <p>매년 10만 마리 이상의 해양 동물이 플라스틱 쓰레기로 인해 죽으며, 바다거북이 가장 큰 피해를 받습니다.</p>
                        </div>
                        <div class="fact-card">
                            <strong>🎣 유령 어업</strong>
                            <p>버려진 어망(유령 그물)은 수십 년 동안 해양 동물을 계속 가두어 엄청난 고통을 줍니다.</p>
                        </div>
                        <div class="fact-card">
                            <strong>🛍️ 플라스틱 혼동</strong>
                            <p>바다거북은 비닐봉지를 좋아하는 먹이인 해파리로 착각하여 장폐색을 일으킵니다.</p>
                        </div>
                        <div class="fact-card">
                            <strong>🏖️ 해변 청소의 힘</strong>
                            <p>한 번의 해변 청소로 수천 개의 해양 쓰레기를 제거하고 수많은 동물의 생명을 구할 수 있습니다.</p>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .turtle-rescue {
                    max-width: 1000px;
                    margin: 0 auto;
                }

                .game-info {
                    text-align: center;
                    margin-bottom: 2rem;
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .game-stats {
                    display: flex;
                    justify-content: space-around;
                    margin-top: 1rem;
                    padding: 1rem;
                    background: rgba(0, 188, 212, 0.2);
                    border-radius: 8px;
                }

                .stat {
                    text-align: center;
                }

                .stat-label {
                    font-size: 0.9rem;
                    opacity: 0.8;
                    margin-bottom: 0.25rem;
                }

                .stat-value {
                    font-size: 1.2rem;
                    font-weight: bold;
                    color: #4fc3f7;
                }

                .ocean-scene {
                    position: relative;
                    width: 100%;
                    height: 500px;
                    background: linear-gradient(180deg, 
                        rgba(0, 150, 136, 0.8) 0%, 
                        rgba(0, 96, 100, 0.9) 50%,
                        rgba(0, 77, 64, 1) 100%);
                    border-radius: 15px;
                    overflow: hidden;
                    margin-bottom: 2rem;
                    cursor: crosshair;
                    border: 3px solid rgba(79, 195, 247, 0.3);
                }

                .water-effect {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: 
                        radial-gradient(circle at 30% 40%, rgba(79, 195, 247, 0.3) 0%, transparent 50%),
                        radial-gradient(circle at 70% 60%, rgba(0, 188, 212, 0.2) 0%, transparent 50%);
                    animation: waterFlow 8s ease-in-out infinite;
                }

                @keyframes waterFlow {
                    0%, 100% { transform: translateX(0) translateY(0); }
                    25% { transform: translateX(20px) translateY(-10px); }
                    50% { transform: translateX(-10px) translateY(15px); }
                    75% { transform: translateX(15px) translateY(-5px); }
                }

                .coral-reef {
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 80px;
                }

                .coral {
                    position: absolute;
                    font-size: 2rem;
                    animation: sway 4s ease-in-out infinite;
                }

                .coral-1 { bottom: 10px; left: 10%; animation-delay: 0s; }
                .coral-2 { bottom: 5px; left: 25%; animation-delay: 1s; }
                .coral-3 { bottom: 15px; right: 20%; animation-delay: 2s; }
                .coral-4 { bottom: 8px; right: 10%; animation-delay: 3s; }

                @keyframes sway {
                    0%, 100% { transform: rotate(-5deg); }
                    50% { transform: rotate(5deg); }
                }

                .turtle {
                    position: absolute;
                    font-size: 2.5rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    user-select: none;
                    z-index: 10;
                }

                .turtle.trapped {
                    opacity: 0.7;
                    animation: struggle 2s ease-in-out infinite;
                }

                .turtle.rescued {
                    animation: swimAway 2s ease-out forwards;
                    pointer-events: none;
                }

                @keyframes struggle {
                    0%, 100% { transform: rotate(-3deg) scale(1); }
                    50% { transform: rotate(3deg) scale(1.05); }
                }

                @keyframes swimAway {
                    0% { transform: scale(1) rotate(0deg); opacity: 1; }
                    50% { transform: scale(1.2) rotate(360deg); opacity: 0.8; }
                    100% { transform: scale(0.5) translateY(-100px); opacity: 0; }
                }

                .threat {
                    position: absolute;
                    font-size: 1.5rem;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    user-select: none;
                    z-index: 20;
                }

                .threat:hover {
                    transform: scale(1.1);
                    filter: brightness(1.2);
                }

                .threat.removing {
                    animation: removeEffect 0.5s ease-out forwards;
                }

                @keyframes removeEffect {
                    0% { transform: scale(1) rotate(0deg); opacity: 1; }
                    50% { transform: scale(1.3) rotate(180deg); opacity: 0.5; }
                    100% { transform: scale(0) rotate(360deg); opacity: 0; }
                }

                .fishing-net {
                    color: #8d6e63;
                    transform: rotate(45deg);
                }

                .plastic-bag {
                    color: rgba(255, 255, 255, 0.7);
                    animation: float 3s ease-in-out infinite;
                }

                .plastic-debris {
                    color: #ff5722;
                }

                .oil-spill {
                    color: #424242;
                    border-radius: 50%;
                    background: radial-gradient(circle, rgba(66, 66, 66, 0.8) 0%, transparent 70%);
                    width: 40px;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                @keyframes float {
                    0%, 100% { transform: translateY(0px); }
                    50% { transform: translateY(-10px); }
                }

                .rescue-instructions {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                    margin-bottom: 2rem;
                }

                .rescue-instructions h4 {
                    color: #4fc3f7;
                    text-align: center;
                    margin-bottom: 1rem;
                }

                .instruction-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                }

                .instruction {
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    text-align: center;
                    border: 1px solid rgba(79, 195, 247, 0.3);
                }

                .threat-icon {
                    font-size: 1.5rem;
                    display: block;
                    margin-bottom: 0.5rem;
                }

                .instruction strong {
                    color: #4fc3f7;
                    display: block;
                    margin-bottom: 0.5rem;
                }

                .instruction p {
                    font-size: 0.9rem;
                    margin: 0;
                    opacity: 0.9;
                }

                .game-controls {
                    display: flex;
                    gap: 1rem;
                    justify-content: center;
                    margin-bottom: 2rem;
                    flex-wrap: wrap;
                }

                .control-btn {
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border: none;
                    padding: 10px 20px;
                    border-radius: 20px;
                    color: white;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    font-weight: 600;
                }

                .control-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(0, 188, 212, 0.4);
                }

                .control-btn:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                    transform: none;
                }

                .educational-facts {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                }

                .educational-facts h4 {
                    color: #4fc3f7;
                    text-align: center;
                    margin-bottom: 1rem;
                }

                .facts-container {
                    position: relative;
                    min-height: 80px;
                }

                .fact-card {
                    position: absolute;
                    width: 100%;
                    opacity: 0;
                    transition: opacity 0.5s ease;
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    border-left: 4px solid #4fc3f7;
                }

                .fact-card.active {
                    opacity: 1;
                    position: relative;
                }

                .fact-card strong {
                    color: #4fc3f7;
                    display: block;
                    margin-bottom: 0.5rem;
                }

                .click-effect {
                    position: absolute;
                    pointer-events: none;
                    z-index: 1000;
                    color: #4fc3f7;
                    font-weight: bold;
                    animation: clickRipple 1s ease-out forwards;
                }

                @keyframes clickRipple {
                    0% { 
                        transform: scale(0.5); 
                        opacity: 1; 
                    }
                    100% { 
                        transform: scale(2); 
                        opacity: 0; 
                    }
                }

                @media (max-width: 768px) {
                    .ocean-scene {
                        height: 400px;
                    }
                    
                    .game-stats {
                        flex-direction: column;
                        gap: 0.5rem;
                    }

                    .stat {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }

                    .instruction-grid {
                        grid-template-columns: repeat(2, 1fr);
                    }

                    .turtle {
                        font-size: 2rem;
                    }

                    .threat {
                        font-size: 1.2rem;
                    }
                }

                @media (max-width: 480px) {
                    .instruction-grid {
                        grid-template-columns: 1fr;
                    }
                    
                    .game-controls {
                        flex-direction: column;
                        align-items: center;
                    }

                    .control-btn {
                        width: 100%;
                        max-width: 200px;
                    }
                }
            </style>
        `;
    }

    setupEventListeners() {
        document.getElementById('start-rescue').addEventListener('click', () => {
            this.start();
        });

        document.getElementById('reset-rescue').addEventListener('click', () => {
            this.reset();
        });

        document.getElementById('pause-rescue').addEventListener('click', () => {
            this.togglePause();
        });

        // Cycle through educational facts
        this.startFactsCycle();
    }

    start() {
        this.isActive = true;
        this.turtlesSaved = 0;
        this.score = 0;
        this.timeRemaining = 120;
        this.turtles = [];
        this.threats = [];
        
        this.updateUI();
        this.generateOceanLife();
        this.startTimer();
        
        // Update button states
        document.getElementById('start-rescue').disabled = true;
        document.getElementById('pause-rescue').disabled = false;
    }

    generateOceanLife() {
        const oceanScene = document.getElementById('ocean-scene');
        
        // Clear existing turtles and threats
        oceanScene.querySelectorAll('.turtle, .threat').forEach(el => el.remove());
        
        // Generate turtles with threats
        for (let i = 0; i < this.totalTurtles; i++) {
            this.createTurtleWithThreat(i);
        }
    }

    createTurtleWithThreat(index) {
        const oceanScene = document.getElementById('ocean-scene');
        const sceneRect = oceanScene.getBoundingClientRect();
        
        // Create turtle
        const turtle = document.createElement('div');
        turtle.className = 'turtle trapped';
        turtle.innerHTML = '🐢';
        turtle.dataset.id = index;
        
        // Position turtle (avoid coral reef area at bottom)
        const x = Math.random() * (sceneRect.width - 60) + 30;
        const y = Math.random() * (sceneRect.height - 150) + 50;
        
        turtle.style.left = x + 'px';
        turtle.style.top = y + 'px';
        
        oceanScene.appendChild(turtle);
        this.turtles.push(turtle);
        
        // Create random threat near turtle
        this.createThreat(x, y, index);
        
        // Add click handler to turtle (for emergency rescues)
        turtle.addEventListener('click', (e) => {
            e.stopPropagation();
            this.attemptDirectRescue(index);
        });
    }

    createThreat(x, y, turtleId) {
        const oceanScene = document.getElementById('ocean-scene');
        const threatTypes = [
            { type: 'fishing-net', icon: '🎣', points: 20 },
            { type: 'plastic-bag', icon: '🛍️', points: 15 },
            { type: 'plastic-debris', icon: '🥤', points: 10 },
            { type: 'oil-spill', icon: '🛢️', points: 25 }
        ];
        
        const threatData = threatTypes[Math.floor(Math.random() * threatTypes.length)];
        
        const threat = document.createElement('div');
        threat.className = `threat ${threatData.type}`;
        threat.innerHTML = threatData.icon;
        threat.dataset.turtleId = turtleId;
        threat.dataset.points = threatData.points;
        
        // Position threat near turtle with some randomness
        const offsetX = (Math.random() - 0.5) * 100;
        const offsetY = (Math.random() - 0.5) * 100;
        
        threat.style.left = Math.max(10, Math.min(x + offsetX, 850)) + 'px';
        threat.style.top = Math.max(10, Math.min(y + offsetY, 400)) + 'px';
        
        oceanScene.appendChild(threat);
        this.threats.push(threat);
        
        // Add click handler to remove threat
        threat.addEventListener('click', (e) => {
            e.stopPropagation();
            this.removeThreat(threat);
        });
    }

    removeThreat(threatElement) {
        if (!this.isActive) return;
        
        const turtleId = parseInt(threatElement.dataset.turtleId);
        const points = parseInt(threatElement.dataset.points);
        const turtle = this.turtles[turtleId];
        
        // Add visual effect
        threatElement.classList.add('removing');
        
        // Add click effect
        this.showClickEffect(threatElement.getBoundingClientRect());
        
        // Remove threat after animation
        setTimeout(() => {
            if (threatElement.parentNode) {
                threatElement.parentNode.removeChild(threatElement);
            }
            
            // Check if turtle is now free (no more threats near it)
            const remainingThreats = this.threats.filter(t => 
                t.dataset.turtleId === turtleId.toString() && 
                t !== threatElement
            );
            
            if (remainingThreats.length === 0 && turtle) {
                this.rescueTurtle(turtle, points);
            }
        }, 500);
        
        // Update score
        this.score += points;
        this.updateUI();
        
        AudioManager.playTurtleRescue();
    }

    rescueTurtle(turtle, bonusPoints = 0) {
        if (turtle.classList.contains('rescued')) return;
        
        turtle.classList.remove('trapped');
        turtle.classList.add('rescued');
        
        this.turtlesSaved++;
        this.score += 50 + bonusPoints; // Base rescue points plus bonus
        
        // Show rescue effect
        this.showClickEffect(turtle.getBoundingClientRect(), '🎉 RESCUED! +' + (50 + bonusPoints));
        
        this.updateUI();
        AudioManager.playSuccess();
        
        // Check win condition
        if (this.turtlesSaved >= this.totalTurtles) {
            setTimeout(() => this.completeGame(), 1000);
        }
    }

    attemptDirectRescue(turtleId) {
        // Direct turtle rescue is less effective and costs points
        const turtle = this.turtles[turtleId];
        const remainingThreats = this.threats.filter(t => 
            t.dataset.turtleId === turtleId.toString()
        );
        
        if (remainingThreats.length > 0) {
            this.score = Math.max(0, this.score - 10);
            this.showClickEffect(turtle.getBoundingClientRect(), '⚠️ Remove threats first! -10');
            this.updateUI();
        }
    }

    showClickEffect(rect, text = '+10') {
        const effect = document.createElement('div');
        effect.className = 'click-effect';
        effect.textContent = text;
        effect.style.left = (rect.left + rect.width / 2) + 'px';
        effect.style.top = (rect.top + rect.height / 2) + 'px';
        
        document.body.appendChild(effect);
        
        setTimeout(() => {
            if (effect.parentNode) {
                effect.parentNode.removeChild(effect);
            }
        }, 1000);
    }

    startTimer() {
        this.gameTimer = setInterval(() => {
            this.timeRemaining--;
            this.updateUI();
            
            if (this.timeRemaining <= 0) {
                this.endGame();
            }
        }, 1000);
    }

    togglePause() {
        const pauseBtn = document.getElementById('pause-rescue');
        
        if (this.gameTimer) {
            // Pause
            clearInterval(this.gameTimer);
            this.gameTimer = null;
            pauseBtn.innerHTML = '▶️ Resume';
            pauseBtn.style.background = 'linear-gradient(45deg, #4caf50, #8bc34a)';
        } else {
            // Resume
            this.startTimer();
            pauseBtn.innerHTML = '⏸️ Pause';
            pauseBtn.style.background = 'linear-gradient(45deg, #00bcd4, #4fc3f7)';
        }
    }

    updateUI() {
        document.getElementById('turtles-saved').textContent = `${this.turtlesSaved}/${this.totalTurtles}`;
        document.getElementById('rescue-score').textContent = this.score;
        
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        document.getElementById('time-remaining').textContent = 
            `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        // Change time color when running low
        const timeElement = document.getElementById('time-remaining');
        if (this.timeRemaining <= 30) {
            timeElement.style.color = '#f44336';
        } else if (this.timeRemaining <= 60) {
            timeElement.style.color = '#ff9800';
        } else {
            timeElement.style.color = '#4fc3f7';
        }
    }

    endGame() {
        this.isActive = false;
        if (this.gameTimer) {
            clearInterval(this.gameTimer);
            this.gameTimer = null;
        }
        
        // Update button states
        document.getElementById('start-rescue').disabled = false;
        document.getElementById('pause-rescue').disabled = true;
        
        if (this.turtlesSaved >= this.totalTurtles) {
            this.completeGame();
        } else {
            this.showGameOver();
        }
    }

    showGameOver() {
        const message = `시간 종료! ${this.totalTurtles}마리 중 ${this.turtlesSaved}마리를 구했습니다. 다시 시도해보세요!`;
        alert(message);
        this.reset();
    }

    completeGame() {
        this.isActive = false;
        if (this.gameTimer) {
            clearInterval(this.gameTimer);
        }
        
        const timeBonus = this.timeRemaining * 5;
        this.score += timeBonus;
        
        const achievement = {
            title: '🐢 바다거북 영웅!',
            message: `<p>놀랍습니다! 모든 바다거북 ${this.totalTurtles}마리를 구하고 ${this.score}점을 획득했습니다!</p>
                     <p>시간 보너스: +${timeBonus}점</p>`,
            tip: '<div class="achievement-tip"><strong>🌊 해양 보호:</strong><br>인간의 행동이 해양 생물에 직접적인 영향을 미치는 것을 배웠습니다. 바다에서 제거한 모든 쓰레기가 수많은 동물을 구합니다!</div>'
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('turtle', achievement);
    }

    startFactsCycle() {
        const facts = document.querySelectorAll('.fact-card');
        let currentFact = 0;
        
        setInterval(() => {
            facts[currentFact].classList.remove('active');
            currentFact = (currentFact + 1) % facts.length;
            facts[currentFact].classList.add('active');
        }, 5000);
    }

    reset() {
        this.isActive = false;
        this.turtlesSaved = 0;
        this.score = 0;
        this.timeRemaining = 120;
        
        if (this.gameTimer) {
            clearInterval(this.gameTimer);
            this.gameTimer = null;
        }
        
        // Clear ocean scene
        const oceanScene = document.getElementById('ocean-scene');
        oceanScene.querySelectorAll('.turtle, .threat').forEach(el => el.remove());
        
        this.updateUI();
        
        // Update button states
        document.getElementById('start-rescue').disabled = false;
        document.getElementById('pause-rescue').disabled = true;
        document.getElementById('pause-rescue').innerHTML = '⏸️ 일시정지';
        document.getElementById('pause-rescue').style.background = 'linear-gradient(45deg, #00bcd4, #4fc3f7)';
    }
}
