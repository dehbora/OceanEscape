// Coral Reef Restoration Mini-Game
class CoralReefGame {
    constructor(container, gameController) {
        this.container = container;
        this.gameController = gameController;
        this.isActive = false;
        this.score = 0;
        this.coralsPlanted = 0;
        this.totalCorals = 12;
        this.timeRemaining = 180; // 3 minutes for strategy-based gameplay
        this.gameTimer = null;
        this.reefZones = [];
        this.selectedCoralType = null;
        this.plantedCorals = new Map();
        this.reefHealth = 0;
        
        // Coral types with different properties
        this.coralTypes = [
            {
                id: 'brain',
                name: '뇌산호',
                emoji: '🧠',
                color: '#E6B800',
                growth: 'slow',
                resilience: 'high',
                symbiosis: ['clownfish', 'cleaner-fish'],
                points: 15,
                description: '천천히 자라지만 스트레스 환경에서 잘 생존하는 강한 산호'
            },
            {
                id: 'staghorn',
                name: '사슴뿔산호',
                emoji: '🪸',
                color: '#FF6B47',
                growth: 'fast',
                resilience: 'medium',
                symbiosis: ['tropical-fish', 'sea-urchins'],
                points: 10,
                description: '빨리 자라고 은신처를 제공하지만 수온 변화에 민감한 산호'
            },
            {
                id: 'table',
                name: '테이블산호',
                emoji: '🏔️',
                color: '#4ECDC4',
                growth: 'medium',
                resilience: 'medium',
                symbiosis: ['angelfish', 'wrasse'],
                points: 12,
                description: '적당한 성장과 복원력으로 훌륭한 어류 서식지 제공'
            },
            {
                id: 'soft',
                name: '연산호',
                emoji: '🌺',
                color: '#FF69B4',
                growth: 'fast',
                resilience: 'low',
                symbiosis: ['butterflyfish', 'gobies'],
                points: 8,
                description: '아름답고 빨리 자라지만 최적의 수질 조건 필요'
            }
        ];
        
        // Environmental factors that affect coral health
        this.environmentalFactors = {
            temperature: 75, // Optimal: 72-78°F
            acidity: 8.1,    // Optimal: 8.0-8.3 pH
            pollution: 20,   // Optimal: 0-10%
            nutrients: 15    // Optimal: 10-20%
        };
        
        this.init();
    }

    init() {
        this.createGameHTML();
        this.setupEventListeners();
        this.generateReefZones();
    }

    createGameHTML() {
        this.container.innerHTML = `
            <div class="coral-reef-game">
                <div class="game-info">
                    <h3>🪸 산호초 복원</h3>
                    <p>전략적으로 산호를 심어 손상된 산호초 생태계를 복원하세요. 성장 속도, 회복력, 물고기 공생 관계를 고려하세요!</p>
                    <div class="game-stats">
                        <div class="stat">
                            <div class="stat-label">심은 산호</div>
                            <div class="stat-value" id="corals-planted">${this.coralsPlanted}/${this.totalCorals}</div>
                        </div>
                        <div class="stat">
                            <div class="stat-label">산호초 건강도</div>
                            <div class="stat-value" id="reef-health">${this.reefHealth}%</div>
                        </div>
                        <div class="stat">
                            <div class="stat-label">점수</div>
                            <div class="stat-value" id="reef-score">${this.score}</div>
                        </div>
                        <div class="stat">
                            <div class="stat-label">시간</div>
                            <div class="stat-value" id="reef-time">3:00</div>
                        </div>
                    </div>
                </div>

                <div class="coral-selection-panel">
                    <h4>🌊 산호 유형 선택</h4>
                    <div class="coral-types" id="coral-types">
                        ${this.coralTypes.map(coral => `
                            <div class="coral-option" data-coral-id="${coral.id}" title="${coral.description}">
                                <div class="coral-icon">${coral.emoji}</div>
                                <div class="coral-name">${coral.name}</div>
                                <div class="coral-properties">
                                    <span class="growth-rate growth-${coral.growth}">${coral.growth === 'slow' ? '느린' : coral.growth === 'medium' ? '보통' : '빠른'} 성장</span>
                                    <span class="resilience resilience-${coral.resilience}">${coral.resilience === 'low' ? '낮은' : coral.resilience === 'medium' ? '보통' : '높은'} 복원력</span>
                                    <span class="points">+${coral.points} 점</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="reef-environment" id="reef-environment">
                    <div class="environment-controls">
                        <h4>🌡️ Environmental Factors</h4>
                        <div class="env-factors">
                            <div class="env-factor">
                                <label>Temperature: <span id="temp-value">${this.environmentalFactors.temperature}°F</span></label>
                                <input type="range" id="temp-slider" min="68" max="82" value="${this.environmentalFactors.temperature}" 
                                       class="env-slider" data-factor="temperature">
                            </div>
                            <div class="env-factor">
                                <label>pH Level: <span id="ph-value">${this.environmentalFactors.acidity}</span></label>
                                <input type="range" id="ph-slider" min="7.5" max="8.5" step="0.1" value="${this.environmentalFactors.acidity}" 
                                       class="env-slider" data-factor="acidity">
                            </div>
                            <div class="env-factor">
                                <label>Pollution: <span id="pollution-value">${this.environmentalFactors.pollution}%</span></label>
                                <input type="range" id="pollution-slider" min="0" max="50" value="${this.environmentalFactors.pollution}" 
                                       class="env-slider" data-factor="pollution">
                            </div>
                            <div class="env-factor">
                                <label>Nutrients: <span id="nutrients-value">${this.environmentalFactors.nutrients}%</span></label>
                                <input type="range" id="nutrients-slider" min="5" max="35" value="${this.environmentalFactors.nutrients}" 
                                       class="env-slider" data-factor="nutrients">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="reef-area" id="reef-area">
                    <div class="reef-grid" id="reef-grid">
                        <!-- Reef zones will be generated here -->
                    </div>
                    <div class="fish-life" id="fish-life">
                        <!-- Fish will appear as corals are planted -->
                    </div>
                </div>

                <div class="restoration-info">
                    <h4>📚 Coral Restoration Tips</h4>
                    <div class="info-grid">
                        <div class="tip">
                            <span class="tip-icon">🌡️</span>
                            <strong>Temperature Matters</strong>
                            <p>Corals thrive in 72-78°F. Higher temperatures cause bleaching!</p>
                        </div>
                        <div class="tip">
                            <span class="tip-icon">🐠</span>
                            <strong>Fish Partnerships</strong>
                            <p>Some fish help corals by cleaning algae and providing nutrients</p>
                        </div>
                        <div class="tip">
                            <span class="tip-icon">⚖️</span>
                            <strong>Ecosystem Balance</strong>
                            <p>Mix fast and slow-growing corals for a resilient reef</p>
                        </div>
                        <div class="tip">
                            <span class="tip-icon">💧</span>
                            <strong>Water Quality</strong>
                            <p>Optimal pH (8.0-8.3) and low pollution ensure coral health</p>
                        </div>
                    </div>
                </div>

                <div class="educational-facts" id="coral-facts">
                    <div class="fact-display">
                        <h4>🧬 Did You Know?</h4>
                        <p id="current-fact">Coral reefs support 25% of marine life while covering less than 1% of the ocean floor!</p>
                    </div>
                </div>
            </div>
        `;
    }

    setupEventListeners() {
        // Coral type selection
        this.container.addEventListener('click', (e) => {
            if (e.target.closest('.coral-option')) {
                this.selectCoralType(e.target.closest('.coral-option').dataset.coralId);
            }
            
            if (e.target.closest('.reef-zone')) {
                this.plantCoral(e.target.closest('.reef-zone'));
            }
        });

        // Environmental factor sliders
        this.container.addEventListener('input', (e) => {
            if (e.target.classList.contains('env-slider')) {
                this.updateEnvironmentalFactor(e.target.dataset.factor, parseFloat(e.target.value));
            }
        });
    }

    generateReefZones() {
        const reefGrid = document.getElementById('reef-grid');
        const zones = [];
        
        // Create 4x4 grid of reef zones
        for (let row = 0; row < 4; row++) {
            for (let col = 0; col < 4; col++) {
                const zone = document.createElement('div');
                zone.className = 'reef-zone';
                zone.dataset.row = row;
                zone.dataset.col = col;
                zone.innerHTML = `
                    <div class="zone-substrate">🏜️</div>
                    <div class="zone-content"></div>
                `;
                reefGrid.appendChild(zone);
                zones.push({
                    element: zone,
                    row,
                    col,
                    occupied: false,
                    coral: null,
                    health: 0
                });
            }
        }
        
        this.reefZones = zones;
    }

    selectCoralType(coralId) {
        // Remove previous selection
        document.querySelectorAll('.coral-option').forEach(option => {
            option.classList.remove('selected');
        });
        
        // Select new coral type
        const selectedOption = document.querySelector(`[data-coral-id="${coralId}"]`);
        if (selectedOption) {
            selectedOption.classList.add('selected');
            this.selectedCoralType = this.coralTypes.find(coral => coral.id === coralId);
            
            // Play selection sound
            AudioManager.playClick();
        }
    }

    plantCoral(zoneElement) {
        if (!this.selectedCoralType || !this.isActive) return;
        
        const zone = this.reefZones.find(z => z.element === zoneElement);
        if (!zone || zone.occupied) return;
        
        if (this.coralsPlanted >= this.totalCorals) return;
        
        // Plant the coral
        const coral = {
            ...this.selectedCoralType,
            plantedAt: Date.now(),
            health: this.calculateCoralHealth(this.selectedCoralType),
            age: 0
        };
        
        zone.occupied = true;
        zone.coral = coral;
        zone.health = coral.health;
        
        // Update visual
        const zoneContent = zoneElement.querySelector('.zone-content');
        zoneContent.innerHTML = `
            <div class="planted-coral" style="color: ${coral.color}">
                ${coral.emoji}
                <div class="coral-health-bar">
                    <div class="health-fill" style="width: ${coral.health}%"></div>
                </div>
            </div>
        `;
        
        zoneElement.classList.add('occupied');
        
        // Update game state
        this.coralsPlanted++;
        this.score += coral.points;
        this.plantedCorals.set(`${zone.row}-${zone.col}`, coral);
        
        // Spawn fish if appropriate
        this.spawnFish(coral);
        
        // Calculate reef health
        this.calculateReefHealth();
        
        // Update UI
        this.updateGameUI();
        
        // Play planting sound
        AudioManager.playSuccess();
        
        // Check if game complete
        if (this.coralsPlanted >= this.totalCorals) {
            this.completeGame();
        }
    }

    calculateCoralHealth(coralType) {
        const { temperature, acidity, pollution, nutrients } = this.environmentalFactors;
        let health = 100;
        
        // Temperature effects
        if (temperature < 72 || temperature > 78) {
            health -= Math.abs(temperature - 75) * 5;
        }
        
        // pH effects
        if (acidity < 8.0 || acidity > 8.3) {
            health -= Math.abs(acidity - 8.15) * 20;
        }
        
        // Pollution effects
        health -= pollution * 1.5;
        
        // Nutrient effects
        if (nutrients < 10 || nutrients > 20) {
            health -= Math.abs(nutrients - 15) * 2;
        }
        
        // Coral-specific resilience
        if (coralType.resilience === 'high') {
            health += 10;
        } else if (coralType.resilience === 'low') {
            health -= 10;
        }
        
        return Math.max(0, Math.min(100, health));
    }

    calculateReefHealth() {
        let totalHealth = 0;
        let healthyCorals = 0;
        
        this.plantedCorals.forEach(coral => {
            if (coral.health > 50) {
                healthyCorals++;
            }
            totalHealth += coral.health;
        });
        
        // Factor in diversity bonus
        const uniqueTypes = new Set(Array.from(this.plantedCorals.values()).map(c => c.id));
        const diversityBonus = (uniqueTypes.size / this.coralTypes.length) * 20;
        
        this.reefHealth = this.plantedCorals.size > 0 
            ? Math.min(100, (totalHealth / this.plantedCorals.size) + diversityBonus)
            : 0;
    }

    spawnFish(coral) {
        const fishLife = document.getElementById('fish-life');
        
        coral.symbiosis.forEach((fishType, index) => {
            setTimeout(() => {
                const fish = document.createElement('div');
                fish.className = 'swimming-fish';
                fish.innerHTML = this.getFishEmoji(fishType);
                fish.style.left = Math.random() * 80 + '%';
                fish.style.top = Math.random() * 60 + 20 + '%';
                fish.style.animationDelay = Math.random() * 2 + 's';
                fishLife.appendChild(fish);
                
                // Remove fish after animation
                setTimeout(() => {
                    if (fish.parentNode) {
                        fish.parentNode.removeChild(fish);
                    }
                }, 8000);
            }, index * 1000);
        });
    }

    getFishEmoji(fishType) {
        const fishEmojis = {
            'clownfish': '🐠',
            'cleaner-fish': '🐟',
            'tropical-fish': '🐠',
            'sea-urchins': '🔆',
            'angelfish': '🐠',
            'wrasse': '🐟',
            'butterflyfish': '🦋',
            'gobies': '🐟'
        };
        return fishEmojis[fishType] || '🐟';
    }

    updateEnvironmentalFactor(factor, value) {
        this.environmentalFactors[factor] = value;
        
        // Update display
        const displays = {
            'temperature': 'temp-value',
            'acidity': 'ph-value',
            'pollution': 'pollution-value',
            'nutrients': 'nutrients-value'
        };
        
        const display = document.getElementById(displays[factor]);
        if (display) {
            if (factor === 'temperature') {
                display.textContent = `${value}°F`;
            } else if (factor === 'acidity') {
                display.textContent = value.toFixed(1);
            } else {
                display.textContent = `${value}%`;
            }
        }
        
        // Recalculate health for all planted corals
        this.plantedCorals.forEach((coral, key) => {
            const newHealth = this.calculateCoralHealth(coral);
            coral.health = newHealth;
            
            // Update visual health bars
            const [row, col] = key.split('-');
            const zone = this.reefZones.find(z => z.row == row && z.col == col);
            if (zone) {
                const healthFill = zone.element.querySelector('.health-fill');
                if (healthFill) {
                    healthFill.style.width = `${newHealth}%`;
                    healthFill.style.backgroundColor = newHealth > 70 ? '#4CAF50' : 
                                                     newHealth > 40 ? '#FF9800' : '#F44336';
                }
            }
        });
        
        this.calculateReefHealth();
        this.updateGameUI();
        
        // Play adjustment sound
        AudioManager.playMicroplasticAdjust();
    }

    updateGameUI() {
        document.getElementById('corals-planted').textContent = `${this.coralsPlanted}/${this.totalCorals}`;
        document.getElementById('reef-health').textContent = `${Math.round(this.reefHealth)}%`;
        document.getElementById('reef-score').textContent = this.score;
        
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        document.getElementById('reef-time').textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    start() {
        this.isActive = true;
        this.showRandomFact();
        this.startTimer();
        
        // Select first coral type by default
        this.selectCoralType(this.coralTypes[0].id);
        
        console.log('Coral Reef Restoration game started');
    }

    startTimer() {
        this.gameTimer = setInterval(() => {
            this.timeRemaining--;
            this.updateGameUI();
            
            if (this.timeRemaining <= 0) {
                this.endGame();
            }
        }, 1000);
    }

    showRandomFact() {
        const facts = [
            "Coral reefs support 25% of marine life while covering less than 1% of the ocean floor!",
            "A single coral colony can live for hundreds or even thousands of years!",
            "Corals are animals, not plants! They have a symbiotic relationship with algae.",
            "Great Barrier Reef is the largest living structure on Earth, visible from space!",
            "Coral reefs protect coastlines from storm damage and erosion.",
            "Ocean acidification from CO2 absorption makes it harder for corals to build skeletons.",
            "Coral bleaching occurs when stressed corals expel their colorful algae partners.",
            "Healthy reefs can recover from damage if given proper protection and time.",
            "Some corals reproduce by releasing billions of eggs and sperm during coral spawning events.",
            "Parrotfish help reefs by eating algae and producing sand - beaches are partly fish waste!"
        ];
        
        const factElement = document.getElementById('current-fact');
        if (factElement) {
            const randomFact = facts[Math.floor(Math.random() * facts.length)];
            factElement.textContent = randomFact;
        }
        
        // Show new fact every 30 seconds
        setTimeout(() => {
            if (this.isActive) {
                this.showRandomFact();
            }
        }, 30000);
    }

    completeGame() {
        this.endGame(true);
    }

    endGame(completed = false) {
        this.isActive = false;
        
        if (this.gameTimer) {
            clearInterval(this.gameTimer);
            this.gameTimer = null;
        }
        
        // Calculate final bonus based on reef health
        let healthBonus = 0;
        if (this.reefHealth >= 80) {
            healthBonus = 100;
            this.score += healthBonus;
        } else if (this.reefHealth >= 60) {
            healthBonus = 50;
            this.score += healthBonus;
        } else if (this.reefHealth >= 40) {
            healthBonus = 25;
            this.score += healthBonus;
        }
        
        // Calculate diversity bonus
        const uniqueTypes = new Set(Array.from(this.plantedCorals.values()).map(c => c.id));
        const diversityBonus = uniqueTypes.size === this.coralTypes.length ? 75 : 0;
        this.score += diversityBonus;
        
        const timeBonus = completed ? this.timeRemaining * 2 : 0;
        this.score += timeBonus;
        
        // Submit score to leaderboard
        const gameData = {
            score: this.score,
            coralsPlanted: this.coralsPlanted,
            reefHealth: Math.round(this.reefHealth),
            timeUsed: 180 - this.timeRemaining,
            completed: completed,
            bonuses: {
                health: healthBonus,
                diversity: diversityBonus,
                time: timeBonus
            }
        };
        
        if (window.gameScoring) {
            window.gameScoring.submitScore('coralreef', this.score, gameData);
        }
        
        // Show completion message
        this.showCompletionMessage(completed, gameData);
        
        // Mark game as completed and return to main game
        if (completed) {
            AudioManager.playAchievement();
            this.gameController.completeMinigame('coralreef');
        } else {
            this.gameController.showGameScreen();
        }
    }

    showCompletionMessage(completed, gameData) {
        const message = completed 
            ? `🎉 Reef Restored Successfully! 🪸\n\nCorals Planted: ${gameData.coralsPlanted}/${this.totalCorals}\nReef Health: ${gameData.reefHealth}%\nFinal Score: ${gameData.score}\n\nBonuses:\n• Health Bonus: +${gameData.bonuses.health}\n• Diversity Bonus: +${gameData.bonuses.diversity}\n• Time Bonus: +${gameData.bonuses.time}`
            : `⏰ Time's Up! \n\nCorals Planted: ${gameData.coralsPlanted}/${this.totalCorals}\nReef Health: ${gameData.reefHealth}%\nFinal Score: ${gameData.score}\n\nTip: Focus on water quality and coral diversity for better results!`;
        
        alert(message);
    }
}