// Microplastic Measurement Mini-Game
class MicroplasticGame {
    constructor(container, gameController) {
        this.container = container;
        this.gameController = gameController;
        this.isActive = false;
        this.currentSample = 0;
        this.totalSamples = 6;
        this.completedSamples = 0;
        this.score = 0;
        this.samples = [];
        
        // Initialize timer and scoring systems
        this.timer = new GameTimer(300, (time, formatted) => {
            TimerScoringUI.updateTimerDisplay('micro-timer', time, 300);
        }, () => {
            this.timeUp();
        });
        this.scoring = new GameScoring('microplastic', 150);
        
        // Define pollution levels and safe ranges
        this.pollutionTypes = {
            'microfibers': { 
                name: '미세섬유', 
                unit: '섬유/L', 
                safeMax: 50, 
                color: '#e91e63',
                source: '합성 의류 및 섬유'
            },
            'microbeads': { 
                name: '미세플라스틱 비즈', 
                unit: '비즈/L', 
                safeMax: 10, 
                color: '#9c27b0',
                source: '개인 위생용품 및 화장품'
            },
            'plastic_fragments': { 
                name: '플라스틱 조각', 
                unit: '조각/L', 
                safeMax: 25, 
                color: '#f44336',
                source: '분해된 플라스틱 쓰레기'
            },
            'synthetic_particles': { 
                name: '합성 입자', 
                unit: '입자/L', 
                safeMax: 75, 
                color: '#ff9800',
                source: '산업 공정 및 타이어 마모'
            }
        };
        
        this.init();
    }

    init() {
        this.createGameHTML();
        this.setupEventListeners();
        this.generateSamples();
    }

    createGameHTML() {
        this.container.innerHTML = `
            <div class="microplastic-game">
                <div class="game-info">
                    <h3>🔬 미세플라스틱 측정 실험실</h3>
                    <p>여과 및 처리 수준을 조정하여 미세플라스틱 오염을 해양 생물에 안전한 범위로 낮추세요.</p>
                    <div class="sample-progress">
                        <span>샘플 <span id="current-sample">1</span> / ${this.totalSamples}</span>
                        <div class="progress-bar">
                            <div class="progress-fill" id="sample-progress"></div>
                        </div>
                        <span>점수: <strong id="micro-score">0</strong>점</span>
                    </div>
                </div>

                <div class="laboratory-workspace">
                    <div class="sample-info" id="sample-info">
                        <!-- Current sample info will be displayed here -->
                    </div>

                    <div class="measurement-controls">
                        <h4>🛠️ 처리 컨트롤</h4>
                        <div class="controls-grid" id="controls-grid">
                            <!-- Controls will be dynamically generated -->
                        </div>
                    </div>

                    <div class="pollution-display">
                        <h4>📊 현재 오염 수준</h4>
                        <div class="pollution-meters" id="pollution-meters">
                            <!-- Pollution meters will be displayed here -->
                        </div>
                    </div>

                    <div class="sample-actions">
                        <button id="test-sample" class="action-btn" disabled>🧪 샘플 테스트</button>
                        <button id="submit-sample" class="action-btn" disabled>✅ 결과 제출</button>
                        <button id="reset-sample" class="action-btn">🔄 샘플 초기화</button>
                    </div>
                </div>

                <div class="treatment-info">
                    <h4>⚙️ 처리 방법:</h4>
                    <div class="treatment-grid">
                        <div class="treatment-card">
                            <strong>🏭 여과 시스템</strong>
                            <p>물리적 필터로 큰 미세플라스틱 입자 제거</p>
                            <small>효과: 100μm 이상 입자에 높음</small>
                        </div>
                        <div class="treatment-card">
                            <strong>🌀 응집</strong>
                            <p>화학 처리로 입자를 뭉치게 함</p>
                            <small>효과: 미세섬유와 작은 입자에 좋음</small>
                        </div>
                        <div class="treatment-card">
                            <strong>💧 부상</strong>
                            <p>공기 방울로 플라스틱 입자를 표면으로 운반</p>
                            <small>효과: 저밀도 플라스틱에 우수</small>
                        </div>
                        <div class="treatment-card">
                            <strong>🧲 자기 분리</strong>
                            <p>자기장을 사용하여 처리된 플라스틱 입자 제거</p>
                            <small>효과: 처리된 미세플라스틱 전용</small>
                        </div>
                    </div>
                </div>

                <div class="educational-section">
                    <h4>📚 Microplastic Facts:</h4>
                    <div class="facts-carousel" id="facts-carousel">
                        <div class="fact-slide active">
                            <strong>🌊 Ocean Contamination</strong>
                            <p>Microplastics are found in 90% of bottled water and 83% of tap water worldwide.</p>
                        </div>
                        <div class="fact-slide">
                            <strong>🐟 Food Chain Impact</strong>
                            <p>Microplastics accumulate in fish and shellfish, eventually reaching human consumers.</p>
                        </div>
                        <div class="fact-slide">
                            <strong>👕 Clothing Source</strong>
                            <p>A single load of laundry can release up to 700,000 microfibers into wastewater.</p>
                        </div>
                        <div class="fact-slide">
                            <strong>🚗 Transportation</strong>
                            <p>Tire wear particles contribute significantly to microplastic pollution in urban areas.</p>
                        </div>
                    </div>
                    <div class="carousel-dots" id="carousel-dots"></div>
                </div>
            </div>

            <style>
                .microplastic-game {
                    max-width: 1000px;
                    margin: 0 auto;
                }

                .game-info {
                    text-align: center;
                    margin-bottom: 2rem;
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .sample-progress {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-top: 1rem;
                    padding: 1rem;
                    background: rgba(0, 188, 212, 0.2);
                    border-radius: 8px;
                }

                .progress-bar {
                    flex: 1;
                    height: 20px;
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 10px;
                    margin: 0 1rem;
                    overflow: hidden;
                }

                .progress-fill {
                    height: 100%;
                    background: linear-gradient(45deg, #4caf50, #8bc34a);
                    transition: width 0.5s ease;
                    width: 16.67%;
                }

                .laboratory-workspace {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                }

                .sample-info {
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                    margin-bottom: 2rem;
                    border-left: 4px solid #4fc3f7;
                }

                .location-tag {
                    display: inline-block;
                    background: rgba(79, 195, 247, 0.3);
                    padding: 0.25rem 0.75rem;
                    border-radius: 15px;
                    font-size: 0.8rem;
                    margin-bottom: 0.5rem;
                }

                .pollution-source {
                    font-style: italic;
                    color: #ff9800;
                    margin-top: 0.5rem;
                }

                .controls-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 1.5rem;
                    margin-bottom: 2rem;
                }

                .control-group {
                    background: rgba(255, 255, 255, 0.05);
                    padding: 1rem;
                    border-radius: 8px;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }

                .control-label {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 0.5rem;
                    font-weight: 600;
                }

                .control-value {
                    color: #4fc3f7;
                    font-family: monospace;
                }

                .slider-container {
                    position: relative;
                    margin-bottom: 0.5rem;
                }

                .treatment-slider {
                    width: 100%;
                    height: 30px;
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 15px;
                    outline: none;
                    -webkit-appearance: none;
                    cursor: pointer;
                }

                .treatment-slider::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    width: 25px;
                    height: 25px;
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border-radius: 50%;
                    cursor: pointer;
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
                    transition: all 0.2s ease;
                }

                .treatment-slider::-webkit-slider-thumb:hover {
                    transform: scale(1.1);
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
                }

                .treatment-slider::-moz-range-thumb {
                    width: 25px;
                    height: 25px;
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border-radius: 50%;
                    cursor: pointer;
                    border: none;
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
                }

                .slider-track {
                    position: absolute;
                    top: 50%;
                    left: 0;
                    right: 0;
                    height: 6px;
                    background: rgba(255, 255, 255, 0.3);
                    border-radius: 3px;
                    transform: translateY(-50%);
                    pointer-events: none;
                }

                .slider-fill {
                    position: absolute;
                    top: 0;
                    left: 0;
                    height: 100%;
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border-radius: 3px;
                    transition: width 0.2s ease;
                }

                .control-description {
                    font-size: 0.8rem;
                    opacity: 0.8;
                    margin-top: 0.5rem;
                }

                .pollution-meters {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                    margin-bottom: 2rem;
                }

                .pollution-meter {
                    background: rgba(255, 255, 255, 0.05);
                    padding: 1rem;
                    border-radius: 8px;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }

                .meter-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 0.5rem;
                }

                .meter-name {
                    font-weight: 600;
                    font-size: 0.9rem;
                }

                .meter-status {
                    padding: 0.2rem 0.6rem;
                    border-radius: 10px;
                    font-size: 0.7rem;
                    font-weight: bold;
                    text-transform: uppercase;
                }

                .meter-status.safe {
                    background: rgba(76, 175, 80, 0.3);
                    color: #4caf50;
                }

                .meter-status.warning {
                    background: rgba(255, 152, 0, 0.3);
                    color: #ff9800;
                }

                .meter-status.danger {
                    background: rgba(244, 67, 54, 0.3);
                    color: #f44336;
                }

                .meter-bar {
                    width: 100%;
                    height: 20px;
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 10px;
                    overflow: hidden;
                    margin-bottom: 0.5rem;
                }

                .meter-fill {
                    height: 100%;
                    transition: all 0.3s ease;
                    position: relative;
                }

                .meter-values {
                    display: flex;
                    justify-content: space-between;
                    font-size: 0.8rem;
                    opacity: 0.8;
                }

                .safe-range {
                    color: #4caf50;
                    font-weight: 600;
                }

                .sample-actions {
                    display: flex;
                    gap: 1rem;
                    justify-content: center;
                    margin-top: 2rem;
                    flex-wrap: wrap;
                }

                .action-btn {
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border: none;
                    padding: 12px 24px;
                    border-radius: 25px;
                    color: white;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    min-width: 140px;
                }

                .action-btn:hover:not(:disabled) {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(0, 188, 212, 0.4);
                }

                .action-btn:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                    transform: none;
                }

                .action-btn.reset {
                    background: linear-gradient(45deg, #ff9800, #ffc107);
                }

                .treatment-info {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                    margin-bottom: 2rem;
                }

                .treatment-info h4 {
                    color: #4fc3f7;
                    text-align: center;
                    margin-bottom: 1rem;
                }

                .treatment-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                    gap: 1rem;
                }

                .treatment-card {
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    border-left: 3px solid #4fc3f7;
                }

                .treatment-card strong {
                    display: block;
                    color: #4fc3f7;
                    margin-bottom: 0.5rem;
                }

                .treatment-card p {
                    margin: 0.5rem 0;
                    font-size: 0.9rem;
                    line-height: 1.4;
                }

                .treatment-card small {
                    color: #8bc34a;
                    font-style: italic;
                }

                .educational-section {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                }

                .educational-section h4 {
                    color: #4fc3f7;
                    text-align: center;
                    margin-bottom: 1rem;
                }

                .facts-carousel {
                    position: relative;
                    min-height: 100px;
                    margin-bottom: 1rem;
                }

                .fact-slide {
                    position: absolute;
                    width: 100%;
                    opacity: 0;
                    transition: opacity 0.5s ease;
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    border-left: 4px solid #4fc3f7;
                }

                .fact-slide.active {
                    opacity: 1;
                    position: relative;
                }

                .fact-slide strong {
                    display: block;
                    color: #4fc3f7;
                    margin-bottom: 0.5rem;
                }

                .carousel-dots {
                    display: flex;
                    justify-content: center;
                    gap: 0.5rem;
                }

                .dot {
                    width: 10px;
                    height: 10px;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.3);
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .dot.active {
                    background: #4fc3f7;
                    transform: scale(1.2);
                }

                .result-notification {
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: rgba(0, 0, 0, 0.9);
                    color: white;
                    padding: 2rem;
                    border-radius: 15px;
                    z-index: 2000;
                    max-width: 400px;
                    text-align: center;
                    animation: slideIn 0.5s ease;
                }

                .result-notification.success {
                    border: 2px solid #4caf50;
                    background: rgba(76, 175, 80, 0.2);
                }

                .result-notification.error {
                    border: 2px solid #f44336;
                    background: rgba(244, 67, 54, 0.2);
                }

                @keyframes slideIn {
                    from {
                        opacity: 0;
                        transform: translate(-50%, -50%) scale(0.8);
                    }
                    to {
                        opacity: 1;
                        transform: translate(-50%, -50%) scale(1);
                    }
                }

                @media (max-width: 768px) {
                    .laboratory-workspace {
                        padding: 1rem;
                    }
                    
                    .controls-grid {
                        grid-template-columns: 1fr;
                    }
                    
                    .pollution-meters {
                        grid-template-columns: 1fr;
                    }
                    
                    .sample-actions {
                        flex-direction: column;
                        align-items: center;
                    }
                    
                    .action-btn {
                        width: 100%;
                        max-width: 250px;
                    }

                    .treatment-grid {
                        grid-template-columns: 1fr;
                    }

                    .sample-progress {
                        flex-direction: column;
                        gap: 0.5rem;
                        text-align: center;
                    }

                    .progress-bar {
                        margin: 0;
                    }
                }
            </style>
        `;
    }

    setupEventListeners() {
        document.getElementById('test-sample').addEventListener('click', () => {
            this.testSample();
        });

        document.getElementById('submit-sample').addEventListener('click', () => {
            this.submitSample();
        });

        document.getElementById('reset-sample').addEventListener('click', () => {
            this.resetCurrentSample();
        });

        // Start facts carousel
        this.startFactsCarousel();
    }

    generateSamples() {
        this.samples = [
            {
                location: 'Coastal Bay',
                description: 'Sample from recreational swimming area near textile factory',
                dominantType: 'microfibers',
                initialLevels: { microfibers: 180, microbeads: 8, plastic_fragments: 45, synthetic_particles: 120 }
            },
            {
                location: 'Urban Harbor',
                description: 'Water sample from busy commercial port area',
                dominantType: 'plastic_fragments',
                initialLevels: { microfibers: 90, microbeads: 25, plastic_fragments: 150, synthetic_particles: 200 }
            },
            {
                location: 'Tourist Beach',
                description: 'Sample from popular beach resort with high cosmetic usage',
                dominantType: 'microbeads',
                initialLevels: { microfibers: 60, microbeads: 45, plastic_fragments: 30, synthetic_particles: 85 }
            },
            {
                location: 'Industrial Estuary',
                description: 'Heavily contaminated area near plastic manufacturing',
                dominantType: 'synthetic_particles',
                initialLevels: { microfibers: 220, microbeads: 35, plastic_fragments: 180, synthetic_particles: 350 }
            },
            {
                location: 'Marine Reserve',
                description: 'Protected area with moderate contamination from distant sources',
                dominantType: 'microfibers',
                initialLevels: { microfibers: 95, microbeads: 12, plastic_fragments: 40, synthetic_particles: 70 }
            },
            {
                location: 'Deep Ocean',
                description: 'Remote deep-sea sample showing global pollution spread',
                dominantType: 'plastic_fragments',
                initialLevels: { microfibers: 55, microbeads: 18, plastic_fragments: 80, synthetic_particles: 110 }
            }
        ];
    }

    start() {
        this.isActive = true;
        this.currentSample = 0;
        this.completedSamples = 0;
        this.score = 0;
        
        // Initialize timer display and start timer
        const timerContainer = document.querySelector('.sample-progress');
        if (timerContainer && !document.getElementById('micro-timer')) {
            timerContainer.innerHTML += '<div class="timer-section" id="micro-timer"></div>';
        }
        TimerScoringUI.createTimerDisplay('micro-timer', 'Time Remaining');
        this.timer.reset();
        this.timer.start();
        
        // Reset scoring
        this.scoring = new GameScoring('microplastic', 150);
        
        this.loadSample();
    }

    loadSample() {
        const sample = this.samples[this.currentSample];
        this.currentLevels = { ...sample.initialLevels };
        this.treatments = {
            filtration: 0,
            coagulation: 0,
            flotation: 0,
            magnetic: 0
        };

        this.updateSampleInfo();
        this.createControls();
        this.updatePollutionMeters();
        this.updateProgress();
        this.updateButtons();
    }

    updateSampleInfo() {
        const sample = this.samples[this.currentSample];
        const dominantPollution = this.pollutionTypes[sample.dominantType];
        
        document.getElementById('sample-info').innerHTML = `
            <div class="location-tag">📍 ${sample.location}</div>
            <h4>Sample Analysis</h4>
            <p>${sample.description}</p>
            <div class="pollution-source">
                <strong>Primary Concern:</strong> ${dominantPollution.name} 
                <span style="color: ${dominantPollution.color};">●</span>
                <br><small>Source: ${dominantPollution.source}</small>
            </div>
        `;
    }

    createControls() {
        const controlsGrid = document.getElementById('controls-grid');
        const treatments = [
            {
                id: 'filtration',
                name: 'Filtration System',
                icon: '🏭',
                description: 'Physical mesh filters (0-100% efficiency)',
                max: 100
            },
            {
                id: 'coagulation',
                name: 'Coagulation Treatment',
                icon: '🌀',
                description: 'Chemical binding agents (0-80% efficiency)',
                max: 80
            },
            {
                id: 'flotation',
                name: 'Air Flotation',
                icon: '💧',
                description: 'Bubble-based separation (0-90% efficiency)',
                max: 90
            },
            {
                id: 'magnetic',
                name: 'Magnetic Separation',
                icon: '🧲',
                description: 'Magnetic field treatment (0-60% efficiency)',
                max: 60
            }
        ];

        controlsGrid.innerHTML = treatments.map(treatment => `
            <div class="control-group">
                <div class="control-label">
                    <span>${treatment.icon} ${treatment.name}</span>
                    <span class="control-value" id="${treatment.id}-value">0%</span>
                </div>
                <div class="slider-container">
                    <div class="slider-track">
                        <div class="slider-fill" id="${treatment.id}-fill"></div>
                    </div>
                    <input 
                        type="range" 
                        class="treatment-slider" 
                        id="${treatment.id}-slider"
                        min="0" 
                        max="${treatment.max}" 
                        value="0"
                        step="5"
                    >
                </div>
                <div class="control-description">${treatment.description}</div>
            </div>
        `).join('');

        // Add event listeners to sliders
        treatments.forEach(treatment => {
            const slider = document.getElementById(`${treatment.id}-slider`);
            const valueDisplay = document.getElementById(`${treatment.id}-value`);
            const fill = document.getElementById(`${treatment.id}-fill`);

            slider.addEventListener('input', (e) => {
                const value = e.target.value;
                this.treatments[treatment.id] = parseInt(value);
                valueDisplay.textContent = value + '%';
                fill.style.width = (value / treatment.max * 100) + '%';
                
                // Enable test button when any treatment is applied
                this.updateButtons();
            });
        });
    }

    updatePollutionMeters() {
        const metersContainer = document.getElementById('pollution-meters');
        
        metersContainer.innerHTML = Object.entries(this.pollutionTypes).map(([key, type]) => {
            const currentLevel = this.currentLevels[key];
            const safeMax = type.safeMax;
            const percentage = Math.min((currentLevel / (safeMax * 2)) * 100, 100);
            
            let status = 'safe';
            if (currentLevel > safeMax * 1.5) status = 'danger';
            else if (currentLevel > safeMax) status = 'warning';
            
            return `
                <div class="pollution-meter">
                    <div class="meter-header">
                        <span class="meter-name">${type.name}</span>
                        <span class="meter-status ${status}">${status}</span>
                    </div>
                    <div class="meter-bar">
                        <div class="meter-fill" style="width: ${percentage}%; background: ${type.color};"></div>
                    </div>
                    <div class="meter-values">
                        <span>Current: ${currentLevel} ${type.unit}</span>
                        <span class="safe-range">Safe: ≤${safeMax} ${type.unit}</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    testSample() {
        // Calculate treatment effects
        this.calculateTreatmentEffects();
        this.updatePollutionMeters();
        
        document.getElementById('test-sample').disabled = true;
        document.getElementById('submit-sample').disabled = false;
        
        this.showNotification('Sample tested! Check the pollution levels and submit when satisfied.', 'success');
        AudioManager.playMicroplasticAdjust();
    }

    calculateTreatmentEffects() {
        const sample = this.samples[this.currentSample];
        
        // Reset to initial levels
        this.currentLevels = { ...sample.initialLevels };
        
        // Apply treatment effects based on pollution type and treatment efficiency
        Object.keys(this.currentLevels).forEach(pollutionType => {
            let reductionFactor = 1;
            
            // Different treatments have different effectiveness on different pollution types
            switch (pollutionType) {
                case 'microfibers':
                    reductionFactor -= (this.treatments.filtration * 0.008); // Filtration very effective
                    reductionFactor -= (this.treatments.coagulation * 0.006); // Coagulation moderately effective
                    reductionFactor -= (this.treatments.flotation * 0.004); // Flotation less effective
                    reductionFactor -= (this.treatments.magnetic * 0.002); // Magnetic least effective
                    break;
                    
                case 'microbeads':
                    reductionFactor -= (this.treatments.filtration * 0.007);
                    reductionFactor -= (this.treatments.coagulation * 0.007);
                    reductionFactor -= (this.treatments.flotation * 0.009); // Flotation very effective for beads
                    reductionFactor -= (this.treatments.magnetic * 0.003);
                    break;
                    
                case 'plastic_fragments':
                    reductionFactor -= (this.treatments.filtration * 0.009); // Excellent for fragments
                    reductionFactor -= (this.treatments.coagulation * 0.005);
                    reductionFactor -= (this.treatments.flotation * 0.007);
                    reductionFactor -= (this.treatments.magnetic * 0.004);
                    break;
                    
                case 'synthetic_particles':
                    reductionFactor -= (this.treatments.filtration * 0.006);
                    reductionFactor -= (this.treatments.coagulation * 0.008); // Very effective for particles
                    reductionFactor -= (this.treatments.flotation * 0.005);
                    reductionFactor -= (this.treatments.magnetic * 0.007); // Good for synthetic particles
                    break;
            }
            
            // Ensure reduction factor doesn't go below 0.1 (minimum 90% reduction)
            reductionFactor = Math.max(0.1, reductionFactor);
            
            // Apply reduction
            this.currentLevels[pollutionType] = Math.round(this.currentLevels[pollutionType] * reductionFactor);
        });
    }

    submitSample() {
        const isSuccess = this.checkSampleSuccess();
        
        if (isSuccess) {
            this.score += this.calculateSampleScore();
            this.completedSamples++;
            
            this.showNotification(
                `✅ 훌륭합니다! 샘플을 성공적으로 정화했습니다!\n+${this.calculateSampleScore()} 점`,
                'success'
            );
            
            AudioManager.playSuccess();
            
            setTimeout(() => {
                this.nextSample();
            }, 2000);
            
        } else {
            const failedTypes = this.getFailedPollutionTypes();
            this.showNotification(
                `❌ 샘플이 아직 오염되어 있습니다!\n감소 필요: ${failedTypes.join(', ')}`,
                'error'
            );
            
            // Allow retesting
            document.getElementById('test-sample').disabled = false;
            document.getElementById('submit-sample').disabled = true;
        }
    }

    checkSampleSuccess() {
        return Object.entries(this.pollutionTypes).every(([key, type]) => {
            return this.currentLevels[key] <= type.safeMax;
        });
    }

    calculateSampleScore() {
        const sample = this.samples[this.currentSample];
        let baseScore = 100;
        
        // Efficiency bonus (less treatment used = higher score)
        const totalTreatment = Object.values(this.treatments).reduce((sum, val) => sum + val, 0);
        const efficiencyBonus = Math.max(0, 100 - Math.floor(totalTreatment / 4));
        
        // Speed bonus based on sample difficulty
        const speedBonus = 50;
        
        return baseScore + efficiencyBonus + speedBonus;
    }

    getFailedPollutionTypes() {
        return Object.entries(this.pollutionTypes)
            .filter(([key, type]) => this.currentLevels[key] > type.safeMax)
            .map(([key, type]) => type.name);
    }

    nextSample() {
        this.currentSample++;
        
        if (this.currentSample >= this.totalSamples) {
            this.completeGame();
        } else {
            this.loadSample();
        }
    }

    resetCurrentSample() {
        // Reset treatments
        Object.keys(this.treatments).forEach(key => {
            this.treatments[key] = 0;
            const slider = document.getElementById(`${key}-slider`);
            const valueDisplay = document.getElementById(`${key}-value`);
            const fill = document.getElementById(`${key}-fill`);
            
            if (slider) {
                slider.value = 0;
                valueDisplay.textContent = '0%';
                fill.style.width = '0%';
            }
        });
        
        // Reset levels to initial
        const sample = this.samples[this.currentSample];
        this.currentLevels = { ...sample.initialLevels };
        
        this.updatePollutionMeters();
        this.updateButtons();
    }

    updateButtons() {
        const hasAnyTreatment = Object.values(this.treatments).some(val => val > 0);
        document.getElementById('test-sample').disabled = !hasAnyTreatment;
        document.getElementById('submit-sample').disabled = true;
    }

    updateProgress() {
        document.getElementById('current-sample').textContent = this.currentSample + 1;
        document.getElementById('micro-score').textContent = this.score;
        
        const progress = ((this.currentSample + 1) / this.totalSamples) * 100;
        document.getElementById('sample-progress').style.width = progress + '%';
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `result-notification ${type}`;
        notification.innerHTML = `<div style="white-space: pre-line;">${message}</div>`;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    startFactsCarousel() {
        const slides = document.querySelectorAll('.fact-slide');
        const dotsContainer = document.getElementById('carousel-dots');
        
        // Create dots
        slides.forEach((_, index) => {
            const dot = document.createElement('div');
            dot.className = `dot ${index === 0 ? 'active' : ''}`;
            dot.addEventListener('click', () => this.goToSlide(index));
            dotsContainer.appendChild(dot);
        });
        
        this.currentSlide = 0;
        
        // Auto-advance slides
        setInterval(() => {
            this.nextSlide();
        }, 6000);
    }

    nextSlide() {
        const slides = document.querySelectorAll('.fact-slide');
        const dots = document.querySelectorAll('.dot');
        
        slides[this.currentSlide].classList.remove('active');
        dots[this.currentSlide].classList.remove('active');
        
        this.currentSlide = (this.currentSlide + 1) % slides.length;
        
        slides[this.currentSlide].classList.add('active');
        dots[this.currentSlide].classList.add('active');
    }

    goToSlide(index) {
        const slides = document.querySelectorAll('.fact-slide');
        const dots = document.querySelectorAll('.dot');
        
        slides[this.currentSlide].classList.remove('active');
        dots[this.currentSlide].classList.remove('active');
        
        this.currentSlide = index;
        
        slides[this.currentSlide].classList.add('active');
        dots[this.currentSlide].classList.add('active');
    }

    completeGame() {
        const averageScore = Math.round(this.score / this.totalSamples);
        let performance = '';
        
        if (averageScore >= 200) performance = 'Outstanding! You\'re a microplastic removal expert!';
        else if (averageScore >= 150) performance = 'Excellent work! You understand water treatment well.';
        else if (averageScore >= 100) performance = 'Good job! You\'ve learned the basics of pollution control.';
        else performance = 'Keep practicing! Every effort helps our oceans.';
        
        this.timer.stop();
        this.isActive = false;
        
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '🔬 Microplastic Specialist!',
            message: `<p>Congratulations! You've successfully treated all ${this.totalSamples} water samples!</p>
                     <div class="score-summary">
                         <p><strong>Final Score:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>Accuracy:</strong> ${stats.accuracy}%</p>
                         <p><strong>Grade:</strong> ${stats.grade}</p>
                         <p><strong>Samples Completed:</strong> ${this.completedSamples}/${this.totalSamples}</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>🌊 Real-World Impact:</strong><br>Water treatment facilities use these exact methods to remove microplastics from drinking water and wastewater. Your choices today can help reduce microplastic pollution!</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: stats.perfectGame,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('microplastic', achievement);
    }

    reset() {
        this.currentSample = 0;
        this.completedSamples = 0;
        this.score = 0;
        this.start();
    }
}
