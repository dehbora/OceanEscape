// Straw Replacement Quiz Mini-Game
class StrawQuizGame {
    constructor(container, gameController) {
        this.container = container;
        this.gameController = gameController;
        this.isActive = false;
        this.currentQuestion = 0;
        this.score = 0;
        this.totalQuestions = 8;
        
        // Initialize timer and scoring systems
        this.timer = new GameTimer(240, (time, formatted) => {
            TimerScoringUI.updateTimerDisplay('straw-timer', time, 240);
        }, () => {
            this.timeUp();
        });
        this.scoring = new GameScoring('straw', 125);
        
        this.questions = [
            {
                question: "미국에서는 하루에 플라스틱 빨대를 몇 개나 사용할까요?",
                options: [
                    "5천만 개",
                    "5억 개", 
                    "10억 개",
                    "50억 개"
                ],
                correct: 1,
                explanation: "미국인들은 매일 약 5억 개의 플라스틱 빨대를 사용합니다 - 지구를 2.5바퀴 돌 수 있는 양입니다!",
                fact: "🌍 미국에서만 연간 1,825억 개의 빨대가 사용됩니다!"
            },
            {
                question: "플라스틱 빨대가 바다에서 분해되는 데 얼마나 걸릴까요?",
                options: [
                    "1-5년",
                    "20-50년",
                    "200-500년",
                    "1000년 이상"
                ],
                correct: 2,
                explanation: "플라스틱 빨대는 분해되는 데 200-500년이 걸리며, 수 세기 동안 해양 생물에 해를 끼칩니다.",
                fact: "🐢 바다거북은 종종 플라스틱 빨대를 먹이로 착각하여 심각한 건강 문제를 겪습니다."
            },
            {
                question: "환경적으로 가장 친환경적인 빨대 대안은 무엇일까요?",
                options: [
                    "종이 빨대",
                    "빨대를 사용하지 않기",
                    "대나무 빨대",
                    "금속 빨대"
                ],
                correct: 1,
                explanation: "가장 좋은 대안은 빨대를 아예 사용하지 않는 것입니다! 대부분의 음료는 빨대가 필요하지 않으며, 완전히 피하면 쓰레기가 발생하지 않습니다.",
                fact: "💡 빨대를 꼭 사용해야 한다면, 금속이나 대나무 같은 재사용 가능한 옵션이 가장 좋습니다."
            },
            {
                question: "해양 쓰레기의 몇 퍼센트가 플라스틱으로 구성되어 있을까요?",
                options: [
                    "30%",
                    "50%",
                    "70%",
                    "80%"
                ],
                correct: 3,
                explanation: "해양 쓰레기의 약 80%가 플라스틱이며, 빨대와 같은 일회용 제품이 주요 원인입니다.",
                fact: "🌊 지금까지 만들어진 모든 플라스틱은 어떤 형태로든 여전히 존재합니다."
            },
            {
                question: "플라스틱 빨대 오염에 가장 많이 영향을 받는 해양 생물은 무엇일까요?",
                options: [
                    "돌고래",
                    "바다거북",
                    "고래", 
                    "물개"
                ],
                correct: 1,
                explanation: "바다거북은 플라스틱 빨대에 특히 취약하며, 종종 콧구멍이나 소화기관에 빨대가 끼입니다.",
                fact: "🐢 코에 빨대가 박힌 바다거북의 영상이 반빨대 운동을 촉발시켰습니다."
            },
            {
                question: "대나무 빨대가 종이 빨대보다 더 나은 주요 이점은 무엇일까요?",
                options: [
                    "더 저렴하다",
                    "재사용 가능하고 물에 젖지 않는다",
                    "맛이 더 좋다",
                    "색상이 더 다양하다"
                ],
                correct: 1,
                explanation: "대나무 빨대는 재사용 가능하고, 종이 빨대처럼 물에 젖지 않으며, 자연적으로 항균성이 있고 생분해됩니다.",
                fact: "🎋 대나무는 매우 빠르게 자랍니다 - 어떤 종은 하루에 최대 90cm까지 자랄 수 있습니다!"
            },
            {
                question: "음식점들이 빨대 오염을 줄이는 데 가장 좋은 방법은 무엇일까요?",
                options: [
                    "요청할 때만 빨대 제공",
                    "종이 빨대로만 전환",
                    "더 짧은 플라스틱 빨대 사용",
                    "사용한 빨대를 모두 재활용"
                ],
                correct: 0,
                explanation: "가장 효과적인 방법은 고객이 특별히 요청할 때만 빨대를 제공하여 전체 사용량을 줄이는 것입니다.",
                fact: "📉 '요청 시 빨대 제공' 정책을 채택한 음식점들은 사용량이 50-80% 감소했습니다."
            },
            {
                question: "일회용 플라스틱 빨대를 처음으로 전국적으로 금지한 국가는 어디일까요?",
                options: [
                    "캐나다",
                    "영국",
                    "프랑스",
                    "코스타리카"
                ],
                correct: 0,
                explanation: "캐나다는 2021년에 처음으로 일회용 플라스틱 빨대를 전국적으로 금지한 국가입니다.",
                fact: "🍁 캐나다의 금지 조치는 2030년까지 일회용 플라스틱을 제거하려는 광범위한 계획의 일부입니다."
            }
        ];
        
        this.init();
    }

    init() {
        this.createGameHTML();
        this.setupEventListeners();
    }

    createGameHTML() {
        this.container.innerHTML = `
            <div class="straw-quiz">
                <div class="quiz-header">
                    <h3>🥤 플라스틱 빨대 오염 퀴즈</h3>
                    <p>플라스틱 빨대와 환경 영향에 대한 지식을 테스트해보세요!</p>
                    <div class="quiz-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" id="quiz-progress"></div>
                        </div>
                        <span class="progress-text" id="quiz-progress-text">문제 1 / ${this.totalQuestions}</span>
                        <div class="quiz-stats">
                            <div class="timer-section" id="straw-timer"></div>
                            <div class="score-section" id="straw-score-section"></div>
                        </div>
                    </div>
                </div>

                <div class="quiz-content" id="quiz-content">
                    <!-- Quiz questions will be inserted here -->
                </div>

                <div class="quiz-results" id="quiz-results" style="display: none;">
                    <!-- Results will be shown here -->
                </div>

                <div class="straw-alternatives">
                    <h4>🌱 친환경 빨대 대안:</h4>
                    <div class="alternatives-grid">
                        <div class="alternative-card">
                            <div class="alt-icon">🚫</div>
                            <h5>빨대 사용 안 함</h5>
                            <p>최고의 선택! 대부분의 음료는 빨대가 필요 없습니다.</p>
                            <div class="rating">★★★★★</div>
                        </div>
                        <div class="alternative-card">
                            <div class="alt-icon">🏗️</div>
                            <h5>스테인리스 스틸</h5>
                            <p>내구성이 좋고, 재사용 가능하며, 세척이 쉽습니다.</p>
                            <div class="rating">★★★★☆</div>
                        </div>
                        <div class="alternative-card">
                            <div class="alt-icon">🎋</div>
                            <h5>대나무</h5>
                            <p>천연 소재, 생분해되며, 항균성이 있습니다.</p>
                            <div class="rating">★★★★☆</div>
                        </div>
                        <div class="alternative-card">
                            <div class="alt-icon">🌾</div>
                            <h5>밀/파스타</h5>
                            <p>농업 폐기물로 만들어지며, 먹을 수 있습니다!</p>
                            <div class="rating">★★★☆☆</div>
                        </div>
                        <div class="alternative-card">
                            <div class="alt-icon">🗞️</div>
                            <h5>종이</h5>
                            <p>플라스틱보다 낫지만 물에 젖을 수 있습니다.</p>
                            <div class="rating">★★☆☆☆</div>
                        </div>
                        <div class="alternative-card">
                            <div class="alt-icon">🌽</div>
                            <h5>PLA 바이오플라스틱</h5>
                            <p>식물 기반이지만 산업용 퇴비화가 필요합니다.</p>
                            <div class="rating">★★☆☆☆</div>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .straw-quiz {
                    max-width: 800px;
                    margin: 0 auto;
                }

                .quiz-header {
                    text-align: center;
                    margin-bottom: 2rem;
                    padding: 1.5rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                }

                .quiz-progress {
                    margin-top: 1rem;
                }

                .progress-bar {
                    width: 100%;
                    height: 20px;
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 10px;
                    overflow: hidden;
                    margin-bottom: 0.5rem;
                }

                .progress-fill {
                    height: 100%;
                    background: linear-gradient(45deg, #4caf50, #8bc34a);
                    transition: width 0.5s ease;
                    width: 12.5%;
                }

                .quiz-content {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                    min-height: 400px;
                }

                .question-card {
                    text-align: center;
                }

                .question-number {
                    color: #4fc3f7;
                    font-size: 1.1rem;
                    margin-bottom: 1rem;
                }

                .question-text {
                    font-size: 1.3rem;
                    margin-bottom: 2rem;
                    line-height: 1.5;
                }

                .options-container {
                    display: grid;
                    gap: 1rem;
                    margin-bottom: 2rem;
                }

                .option-btn {
                    background: rgba(255, 255, 255, 0.1);
                    border: 2px solid rgba(255, 255, 255, 0.3);
                    padding: 1rem 1.5rem;
                    border-radius: 10px;
                    color: white;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    text-align: left;
                    font-size: 1rem;
                    width: 100%;
                }

                .option-btn:hover {
                    background: rgba(79, 195, 247, 0.2);
                    border-color: #4fc3f7;
                    transform: translateY(-2px);
                }

                .option-btn.selected {
                    background: rgba(79, 195, 247, 0.3);
                    border-color: #4fc3f7;
                }

                .option-btn.correct {
                    background: rgba(76, 175, 80, 0.3);
                    border-color: #4caf50;
                }

                .option-btn.incorrect {
                    background: rgba(244, 67, 54, 0.3);
                    border-color: #f44336;
                }

                .explanation {
                    background: rgba(79, 195, 247, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                    margin: 1rem 0;
                    border-left: 4px solid #4fc3f7;
                    display: none;
                }

                .explanation.show {
                    display: block;
                    animation: slideDown 0.5s ease;
                }

                .fact-box {
                    background: rgba(76, 175, 80, 0.1);
                    padding: 1rem;
                    border-radius: 8px;
                    margin-top: 1rem;
                    border-left: 4px solid #4caf50;
                    font-style: italic;
                }

                .next-btn {
                    background: linear-gradient(45deg, #00bcd4, #4fc3f7);
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    color: white;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    display: none;
                    margin: 1rem auto;
                }

                .next-btn.show {
                    display: block;
                }

                .next-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(0, 188, 212, 0.4);
                }

                .quiz-results {
                    text-align: center;
                    padding: 2rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 15px;
                    margin-bottom: 2rem;
                }

                .final-score {
                    font-size: 2rem;
                    margin-bottom: 1rem;
                    color: #4fc3f7;
                }

                .score-message {
                    font-size: 1.2rem;
                    margin-bottom: 2rem;
                }

                .retry-btn {
                    background: linear-gradient(45deg, #ff9800, #ffc107);
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    color: white;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    margin: 0 1rem;
                }

                .retry-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(255, 152, 0, 0.4);
                }

                .straw-alternatives {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 2rem;
                    border-radius: 15px;
                    margin-top: 2rem;
                }

                .straw-alternatives h4 {
                    text-align: center;
                    margin-bottom: 1.5rem;
                    color: #4fc3f7;
                }

                .alternatives-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                }

                .alternative-card {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 10px;
                    text-align: center;
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    transition: transform 0.3s ease;
                }

                .alternative-card:hover {
                    transform: translateY(-3px);
                }

                .alt-icon {
                    font-size: 2rem;
                    margin-bottom: 0.5rem;
                }

                .alternative-card h5 {
                    margin: 0.5rem 0;
                    color: #4fc3f7;
                }

                .alternative-card p {
                    font-size: 0.9rem;
                    margin-bottom: 0.5rem;
                    opacity: 0.9;
                }

                .rating {
                    color: #ffc107;
                    font-size: 0.9rem;
                }

                @keyframes slideDown {
                    from {
                        opacity: 0;
                        transform: translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                @media (max-width: 768px) {
                    .quiz-content {
                        padding: 1rem;
                    }
                    
                    .question-text {
                        font-size: 1.1rem;
                    }
                    
                    .option-btn {
                        padding: 0.8rem 1rem;
                        font-size: 0.9rem;
                    }

                    .alternatives-grid {
                        grid-template-columns: repeat(2, 1fr);
                    }

                    .straw-alternatives {
                        padding: 1rem;
                    }
                }

                @media (max-width: 480px) {
                    .alternatives-grid {
                        grid-template-columns: 1fr;
                    }
                }
            </style>
        `;
    }

    setupEventListeners() {
        // Event listeners will be added dynamically for each question
    }

    start() {
        this.isActive = true;
        this.currentQuestion = 0;
        this.score = 0;
        
        // Initialize timer display and start timer
        TimerScoringUI.createTimerDisplay('straw-timer', '남은 시간');
        TimerScoringUI.createScoreDisplay('straw-score-section', 0);
        this.timer.reset();
        this.timer.start();
        
        // Reset scoring
        this.scoring = new GameScoring('straw', 125);
        
        this.showQuestion();
    }

    showQuestion() {
        const question = this.questions[this.currentQuestion];
        const quizContent = document.getElementById('quiz-content');
        const progressFill = document.getElementById('quiz-progress');
        const progressText = document.getElementById('quiz-progress-text');
        
        // Update progress
        const progress = ((this.currentQuestion + 1) / this.totalQuestions) * 100;
        progressFill.style.width = progress + '%';
        progressText.textContent = `문제 ${this.currentQuestion + 1} / ${this.totalQuestions}`;
        
        quizContent.innerHTML = `
            <div class="question-card">
                <div class="question-number">문제 ${this.currentQuestion + 1}</div>
                <div class="question-text">${question.question}</div>
                <div class="options-container">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${String.fromCharCode(65 + index)}. ${option}
                        </button>
                    `).join('')}
                </div>
                <div class="explanation" id="explanation">
                    <strong>💡 설명:</strong><br>
                    ${question.explanation}
                    <div class="fact-box">
                        ${question.fact}
                    </div>
                </div>
                <button class="next-btn" id="next-btn">
                    ${this.currentQuestion < this.totalQuestions - 1 ? '다음 문제 →' : '결과 보기 →'}
                </button>
            </div>
        `;
        
        // Add event listeners to options
        document.querySelectorAll('.option-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.selectAnswer(parseInt(e.target.dataset.index));
            });
        });
        
        // Add event listener to next button
        document.getElementById('next-btn').addEventListener('click', () => {
            this.nextQuestion();
        });
    }

    selectAnswer(selectedIndex) {
        const question = this.questions[this.currentQuestion];
        const options = document.querySelectorAll('.option-btn');
        const explanation = document.getElementById('explanation');
        const nextBtn = document.getElementById('next-btn');
        
        // Disable all options
        options.forEach(option => {
            option.style.pointerEvents = 'none';
        });
        
        // Highlight correct and incorrect answers
        options.forEach((option, index) => {
            if (index === question.correct) {
                option.classList.add('correct');
            } else if (index === selectedIndex && index !== question.correct) {
                option.classList.add('incorrect');
            }
            
            if (index === selectedIndex) {
                option.classList.add('selected');
            }
        });
        
        // Update score
        if (selectedIndex === question.correct) {
            this.score++;
            AudioManager.playQuizCorrect();
        } else {
            AudioManager.playQuizIncorrect();
        }
        
        // Show explanation and next button
        explanation.classList.add('show');
        nextBtn.classList.add('show');
    }

    nextQuestion() {
        this.currentQuestion++;
        
        if (this.currentQuestion >= this.totalQuestions) {
            this.showResults();
        } else {
            this.showQuestion();
        }
    }

    showResults() {
        const quizContent = document.getElementById('quiz-content');
        const resultsDiv = document.getElementById('quiz-results');
        const percentage = Math.round((this.score / this.totalQuestions) * 100);
        
        let scoreMessage = '';
        let scoreColor = '';
        
        if (percentage >= 90) {
            scoreMessage = '🌟 훌륭합니다! 빨대 오염 전문가입니다!';
            scoreColor = '#4caf50';
        } else if (percentage >= 70) {
            scoreMessage = '👍 잘했습니다! 빨대 오염에 대해 잘 알고 있습니다.';
            scoreColor = '#8bc34a';
        } else if (percentage >= 50) {
            scoreMessage = '📚 나쁘지 않아요! 환경 문제에 대해 계속 배워보세요.';
            scoreColor = '#ffc107';
        } else {
            scoreMessage = '💪 계속 공부하세요! 모든 지식이 바다를 돕습니다.';
            scoreColor = '#ff9800';
        }
        
        quizContent.style.display = 'none';
        resultsDiv.style.display = 'block';
        resultsDiv.innerHTML = `
            <div class="final-score" style="color: ${scoreColor}">
                🎯 점수: ${this.score}/${this.totalQuestions} (${percentage}%)
            </div>
            <div class="score-message">${scoreMessage}</div>
            <div class="results-actions">
                <button class="retry-btn" id="retry-quiz">🔄 다시 풀기</button>
            </div>
            <div style="margin-top: 2rem; padding: 1.5rem; background: rgba(79, 195, 247, 0.1); border-radius: 10px;">
                <h4>🌊 핵심 요점:</h4>
                <ul style="text-align: left; margin-top: 1rem;">
                    <li>🚫 가장 좋은 빨대는 빨대를 사용하지 않는 것</li>
                    <li>♻️ 재사용 대안은 1인당 연간 수백 개의 빨대를 절약</li>
                    <li>🐢 바다거북과 해양 생물은 우리의 선택에 달려 있음</li>
                    <li>🌍 작은 변화가 큰 환경적 영향을 만듦</li>
                </ul>
            </div>
        `;
        
        // Add retry event listener
        document.getElementById('retry-quiz').addEventListener('click', () => {
            this.reset();
        });
        
        // Complete the minigame if score is good enough
        if (percentage >= 50) {
            setTimeout(() => {
                this.completeGame();
            }, 2000);
        }
    }

    completeGame() {
        this.timer.stop();
        this.isActive = false;
        
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '🥤 빨대 오염 전문가!',
            message: `<p>환상적입니다! 플라스틱 빨대 오염과 친환경 대안에 대한 훌륭한 지식을 보여주셨습니다.</p>
                     <div class="score-summary">
                         <p><strong>최종 점수:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>정확도:</strong> ${stats.accuracy}%</p>
                         <p><strong>등급:</strong> ${stats.grade}</p>
                         <p><strong>정답 개수:</strong> ${stats.correctAttempts}/${stats.attempts}</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>🌍 실천하기:</strong><br>친구와 가족에게 당신의 지식을 공유하세요. 재사용 빨대를 선택하거나 아예 빨대를 사용하지 않아 바다를 보호하세요!</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: stats.perfectGame,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('straw', achievement);
    }
    
    timeUp() {
        this.isActive = false;
        this.timer.stop();
        
        const finalScore = this.scoring.calculateFinalScore(this.timer);
        const stats = this.scoring.getStats();
        
        const achievement = {
            title: '⏰ 시간 종료!',
            message: `<p>시간이 다 됐습니다! ${this.totalQuestions}개 문제 중 ${stats.correctAttempts}개를 맞혔습니다.</p>
                     <div class="score-summary">
                         <p><strong>점수:</strong> ${finalScore.toLocaleString()}</p>
                         <p><strong>정확도:</strong> ${stats.accuracy}%</p>
                         <p><strong>진행도:</strong> ${this.currentQuestion}/${this.totalQuestions} 문제</p>
                     </div>`,
            tip: '<div class="achievement-tip"><strong>⚡ 학습 팁:</strong><br>빨대 대안을 복습하고 퀴즈를 다시 풀어 환경 지식을 향상시키세요!</div>',
            scoreData: {
                finalScore: finalScore,
                accuracy: stats.accuracy,
                grade: stats.grade,
                timeUsed: this.timer.getElapsedTime(),
                perfectGame: false,
                timestamp: Date.now()
            }
        };
        
        AudioManager.playAchievement();
        this.gameController.completeMinigame('straw', achievement);
    }

    reset() {
        this.currentQuestion = 0;
        this.score = 0;
        
        const quizContent = document.getElementById('quiz-content');
        const resultsDiv = document.getElementById('quiz-results');
        
        quizContent.style.display = 'block';
        resultsDiv.style.display = 'none';
        
        this.start();
    }
}
