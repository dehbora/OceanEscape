// Leaderboard UI Component
class LeaderboardModal {
    constructor() {
        this.leaderboard = new Leaderboard();
        this.currentGameType = null;
        this.modal = null;
        this.init();
    }

    init() {
        this.createModal();
        this.bindEvents();
    }

    createModal() {
        const modalHTML = `
            <div id="leaderboard-modal" class="modal-overlay" style="display: none;">
                <div class="modal-content leaderboard-modal">
                    <div class="modal-header">
                        <h2>🏆 Leaderboard</h2>
                        <button class="close-modal" id="close-leaderboard">&times;</button>
                    </div>
                    
                    <div class="leaderboard-tabs">
                        <button class="tab-btn active" data-game="all">Overall</button>
                        <button class="tab-btn" data-game="plastic">Plastic Sorting</button>
                        <button class="tab-btn" data-game="straw">Straw Quiz</button>
                        <button class="tab-btn" data-game="turtle">Turtle Rescue</button>
                        <button class="tab-btn" data-game="microplastic">Microplastic</button>
                    </div>
                    
                    <div class="leaderboard-content">
                        <div class="stats-summary" id="stats-summary"></div>
                        <div class="leaderboard-table-container">
                            <table class="leaderboard-table">
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>Score</th>
                                        <th>Grade</th>
                                        <th>Accuracy</th>
                                        <th>Time</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody id="leaderboard-entries"></tbody>
                            </table>
                        </div>
                        
                        <div class="leaderboard-actions">
                            <button class="control-btn" id="clear-scores">🗑️ Clear Scores</button>
                            <button class="control-btn" id="export-stats">📊 Export Stats</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <style>
                .leaderboard-modal {
                    max-width: 800px;
                    width: 90vw;
                    max-height: 80vh;
                    overflow-y: auto;
                }
                
                .leaderboard-tabs {
                    display: flex;
                    gap: 0.5rem;
                    margin-bottom: 1.5rem;
                    flex-wrap: wrap;
                }
                
                .tab-btn {
                    padding: 0.5rem 1rem;
                    border: 2px solid #4fc3f7;
                    background: transparent;
                    color: #4fc3f7;
                    border-radius: 20px;
                    cursor: pointer;
                    font-weight: bold;
                    transition: all 0.3s ease;
                    font-size: 0.9rem;
                }
                
                .tab-btn:hover {
                    background: rgba(79, 195, 247, 0.1);
                    transform: translateY(-2px);
                }
                
                .tab-btn.active {
                    background: #4fc3f7;
                    color: white;
                    box-shadow: 0 4px 15px rgba(79, 195, 247, 0.3);
                }
                
                .stats-summary {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1rem;
                    border-radius: 10px;
                    margin-bottom: 1.5rem;
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                    gap: 1rem;
                }
                
                .stat-item {
                    text-align: center;
                }
                
                .stat-value {
                    font-size: 1.5rem;
                    font-weight: bold;
                    color: #4fc3f7;
                }
                
                .stat-label {
                    font-size: 0.9rem;
                    opacity: 0.8;
                    margin-top: 0.25rem;
                }
                
                .leaderboard-table-container {
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 10px;
                    overflow: hidden;
                    margin-bottom: 1.5rem;
                }
                
                .leaderboard-table {
                    width: 100%;
                    border-collapse: collapse;
                }
                
                .leaderboard-table th,
                .leaderboard-table td {
                    padding: 0.75rem;
                    text-align: center;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                
                .leaderboard-table th {
                    background: rgba(79, 195, 247, 0.2);
                    font-weight: bold;
                    color: #4fc3f7;
                }
                
                .leaderboard-table tr:hover {
                    background: rgba(255, 255, 255, 0.05);
                }
                
                .rank-medal {
                    font-size: 1.2rem;
                }
                
                .grade-badge {
                    display: inline-block;
                    padding: 0.25rem 0.5rem;
                    border-radius: 15px;
                    font-weight: bold;
                    font-size: 0.8rem;
                }
                
                .grade-S { background: #ffd700; color: #333; }
                .grade-A { background: #4caf50; color: white; }
                .grade-B { background: #2196f3; color: white; }
                .grade-C { background: #ff9800; color: white; }
                .grade-D { background: #f44336; color: white; }
                .grade-F { background: #9e9e9e; color: white; }
                
                .leaderboard-actions {
                    display: flex;
                    gap: 1rem;
                    justify-content: center;
                    flex-wrap: wrap;
                }
                
                .empty-leaderboard {
                    text-align: center;
                    padding: 2rem;
                    opacity: 0.6;
                }
                
                @media (max-width: 600px) {
                    .leaderboard-table {
                        font-size: 0.8rem;
                    }
                    
                    .leaderboard-table th,
                    .leaderboard-table td {
                        padding: 0.5rem 0.25rem;
                    }
                    
                    .stats-summary {
                        grid-template-columns: repeat(2, 1fr);
                    }
                }
            </style>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.modal = document.getElementById('leaderboard-modal');
    }

    bindEvents() {
        // Close modal
        document.getElementById('close-leaderboard').addEventListener('click', () => {
            this.hide();
        });
        
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const gameType = e.target.dataset.game;
                this.switchTab(gameType);
            });
        });
        
        // Clear scores
        document.getElementById('clear-scores').addEventListener('click', () => {
            this.clearScores();
        });
        
        // Export stats
        document.getElementById('export-stats').addEventListener('click', () => {
            this.exportStats();
        });
        
        // Close on backdrop click
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.hide();
            }
        });
    }

    show(gameType = 'all') {
        this.currentGameType = gameType;
        this.updateContent();
        this.modal.style.display = 'flex';
        this.modal.classList.add('active');
        
        // Set active tab
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.game === gameType);
        });
    }

    hide() {
        this.modal.style.display = 'none';
        this.modal.classList.remove('active');
    }

    switchTab(gameType) {
        this.currentGameType = gameType;
        this.updateContent();
        
        // Update active tab
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.game === gameType);
        });
    }

    updateContent() {
        this.updateStatsSummary();
        this.updateLeaderboardTable();
    }

    updateStatsSummary() {
        const summaryContainer = document.getElementById('stats-summary');
        
        if (this.currentGameType === 'all') {
            const overallStats = this.leaderboard.getOverallStats();
            summaryContainer.innerHTML = `
                <div class="stat-item">
                    <div class="stat-value">${overallStats.totalGamesPlayed}</div>
                    <div class="stat-label">Games Played</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${overallStats.averageScore.toLocaleString()}</div>
                    <div class="stat-label">Average Score</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${overallStats.bestGame ? overallStats.bestGame.finalScore.toLocaleString() : '0'}</div>
                    <div class="stat-label">Best Score</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${Object.keys(overallStats.gameStats).length}</div>
                    <div class="stat-label">Games Unlocked</div>
                </div>
            `;
        } else {
            const gameStats = this.leaderboard.getOverallStats().gameStats[this.currentGameType] || {};
            const personalBest = this.leaderboard.getPersonalBest(this.currentGameType);
            
            summaryContainer.innerHTML = `
                <div class="stat-item">
                    <div class="stat-value">${gameStats.gamesPlayed || 0}</div>
                    <div class="stat-label">Times Played</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${(gameStats.bestScore || 0).toLocaleString()}</div>
                    <div class="stat-label">Best Score</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${(gameStats.averageScore || 0).toLocaleString()}</div>
                    <div class="stat-label">Average Score</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${personalBest ? personalBest.grade : 'N/A'}</div>
                    <div class="stat-label">Best Grade</div>
                </div>
            `;
        }
    }

    updateLeaderboardTable() {
        const tableBody = document.getElementById('leaderboard-entries');
        
        if (this.currentGameType === 'all') {
            this.showOverallLeaderboard(tableBody);
        } else {
            this.showGameLeaderboard(tableBody, this.currentGameType);
        }
    }

    showOverallLeaderboard(tableBody) {
        const allLeaderboards = this.leaderboard.getLeaderboard();
        const allEntries = [];
        
        Object.entries(allLeaderboards).forEach(([gameType, entries]) => {
            entries.forEach(entry => {
                allEntries.push({ ...entry, gameType });
            });
        });
        
        // Sort by final score
        allEntries.sort((a, b) => b.finalScore - a.finalScore);
        
        if (allEntries.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-leaderboard">
                        <div>🎮 No scores yet!</div>
                        <div>Play some mini-games to see your progress here.</div>
                    </td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = allEntries.slice(0, 10).map((entry, index) => {
            const rankDisplay = index < 3 ? 
                ['🥇', '🥈', '🥉'][index] : 
                `#${index + 1}`;
            
            const gameTypeDisplay = {
                'plastic': 'Plastic Sorting',
                'straw': 'Straw Quiz',
                'turtle': 'Turtle Rescue',
                'microplastic': 'Microplastic'
            }[entry.gameType] || entry.gameType;
            
            return `
                <tr>
                    <td><span class="rank-medal">${rankDisplay}</span></td>
                    <td>${entry.finalScore.toLocaleString()}</td>
                    <td><span class="grade-badge grade-${entry.grade}">${entry.grade}</span></td>
                    <td>${entry.accuracy}%</td>
                    <td>${this.formatTime(entry.timeUsed)} <small>(${gameTypeDisplay})</small></td>
                    <td>${entry.date}</td>
                </tr>
            `;
        }).join('');
    }

    showGameLeaderboard(tableBody, gameType) {
        const entries = this.leaderboard.getLeaderboard(gameType);
        
        if (entries.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-leaderboard">
                        <div>🎮 No scores for this game yet!</div>
                        <div>Complete the mini-game to see your score here.</div>
                    </td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = entries.map((entry, index) => {
            const rankDisplay = index < 3 ? 
                ['🥇', '🥈', '🥉'][index] : 
                `#${index + 1}`;
            
            return `
                <tr>
                    <td><span class="rank-medal">${rankDisplay}</span></td>
                    <td>${entry.finalScore.toLocaleString()}</td>
                    <td><span class="grade-badge grade-${entry.grade}">${entry.grade}</span></td>
                    <td>${entry.accuracy}%</td>
                    <td>${this.formatTime(entry.timeUsed)}</td>
                    <td>${entry.date}</td>
                </tr>
            `;
        }).join('');
    }

    formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }

    clearScores() {
        if (confirm('Are you sure you want to clear all leaderboard data? This cannot be undone.')) {
            if (this.currentGameType === 'all') {
                this.leaderboard.clearLeaderboard();
            } else {
                this.leaderboard.clearLeaderboard(this.currentGameType);
            }
            this.updateContent();
            AudioManager.playSound('click');
        }
    }

    exportStats() {
        const stats = this.leaderboard.getOverallStats();
        const dataStr = JSON.stringify(stats, null, 2);
        const dataBlob = new Blob([dataStr], {type: 'application/json'});
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = 'ocean-escape-stats.json';
        link.click();
        
        AudioManager.playSound('success');
    }

    addNewScore(gameType, scoreData) {
        const rank = this.leaderboard.addScore(gameType, scoreData);
        
        // Show a brief celebration if it's a top score
        if (rank <= 3) {
            this.showTopScoreMessage(rank, scoreData.finalScore);
        }
        
        return rank;
    }

    showTopScoreMessage(rank, score) {
        const messages = [
            `🥇 NEW RECORD! Amazing score of ${score.toLocaleString()}!`,
            `🥈 Incredible! Second place with ${score.toLocaleString()} points!`,
            `🥉 Fantastic! Third place with ${score.toLocaleString()} points!`
        ];
        
        const message = messages[rank - 1];
        
        // Create temporary notification
        const notification = document.createElement('div');
        notification.innerHTML = `
            <div class="top-score-notification">
                ${message}
            </div>
            <style>
                .top-score-notification {
                    position: fixed;
                    top: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: linear-gradient(45deg, #ffd700, #ffed4e);
                    color: #333;
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    font-weight: bold;
                    font-size: 1.1rem;
                    z-index: 10000;
                    box-shadow: 0 8px 25px rgba(255, 215, 0, 0.3);
                    animation: topScoreSlide 4s ease-in-out forwards;
                }
                
                @keyframes topScoreSlide {
                    0% { transform: translateX(-50%) translateY(-100%); opacity: 0; }
                    10%, 80% { transform: translateX(-50%) translateY(0); opacity: 1; }
                    100% { transform: translateX(-50%) translateY(-100%); opacity: 0; }
                }
            </style>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 4000);
    }
}

// Create global leaderboard instance
window.LeaderboardModal = LeaderboardModal;