// Timer and Scoring System for Ocean Escape Room
class GameTimer {
    constructor(duration = 120, onTick = null, onComplete = null) {
        this.duration = duration; // in seconds
        this.timeRemaining = duration;
        this.isRunning = false;
        this.isPaused = false;
        this.interval = null;
        this.startTime = null;
        this.pausedTime = 0;
        
        this.onTick = onTick;
        this.onComplete = onComplete;
    }

    start() {
        if (this.isRunning && !this.isPaused) return;
        
        this.isRunning = true;
        this.isPaused = false;
        this.startTime = Date.now() - this.pausedTime;
        
        this.interval = setInterval(() => {
            this.timeRemaining = Math.max(0, this.duration - Math.floor((Date.now() - this.startTime) / 1000));
            
            if (this.onTick) {
                this.onTick(this.timeRemaining, this.getFormattedTime());
            }
            
            if (this.timeRemaining <= 0) {
                this.stop();
                if (this.onComplete) {
                    this.onComplete();
                }
            }
        }, 100);
    }

    pause() {
        if (!this.isRunning || this.isPaused) return;
        
        this.isPaused = true;
        this.pausedTime = Date.now() - this.startTime;
        clearInterval(this.interval);
    }

    resume() {
        if (!this.isRunning || !this.isPaused) return;
        this.start();
    }

    stop() {
        this.isRunning = false;
        this.isPaused = false;
        clearInterval(this.interval);
    }

    reset() {
        this.stop();
        this.timeRemaining = this.duration;
        this.pausedTime = 0;
        this.startTime = null;
    }

    getFormattedTime() {
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    getElapsedTime() {
        return this.duration - this.timeRemaining;
    }

    getTimeBonus(maxBonus = 1000) {
        // Returns bonus points based on remaining time
        const timeUsed = this.getElapsedTime();
        const timeEfficiency = Math.max(0, 1 - (timeUsed / this.duration));
        return Math.floor(timeEfficiency * maxBonus);
    }
}

class GameScoring {
    constructor(gameType, basePoints = 100) {
        this.gameType = gameType;
        this.basePoints = basePoints;
        this.score = 0;
        this.accuracy = 0;
        this.attempts = 0;
        this.correctAttempts = 0;
        this.streakCount = 0;
        this.maxStreak = 0;
        this.bonusMultiplier = 1;
        this.perfectGame = true;
    }

    addPoints(points, isCorrect = true) {
        this.attempts++;
        
        if (isCorrect) {
            this.correctAttempts++;
            this.streakCount++;
            this.maxStreak = Math.max(this.maxStreak, this.streakCount);
            
            // Apply streak bonus
            const streakBonus = Math.min(this.streakCount * 0.1, 2); // Max 2x multiplier
            const finalPoints = Math.floor(points * (1 + streakBonus) * this.bonusMultiplier);
            this.score += finalPoints;
            
            return finalPoints;
        } else {
            this.streakCount = 0;
            this.perfectGame = false;
            // Small penalty for wrong attempts
            this.score = Math.max(0, this.score - Math.floor(points * 0.1));
            return -Math.floor(points * 0.1);
        }
    }

    getAccuracy() {
        return this.attempts > 0 ? Math.round((this.correctAttempts / this.attempts) * 100) : 100;
    }

    calculateFinalScore(timer = null) {
        let finalScore = this.score;
        
        // Time bonus
        if (timer && timer.timeRemaining > 0) {
            const timeBonus = timer.getTimeBonus(500);
            finalScore += timeBonus;
        }
        
        // Perfect game bonus
        if (this.perfectGame && this.attempts > 0) {
            finalScore += Math.floor(finalScore * 0.2); // 20% bonus
        }
        
        // High accuracy bonus
        const accuracy = this.getAccuracy();
        if (accuracy >= 90) {
            finalScore += Math.floor(finalScore * 0.1); // 10% bonus
        }
        
        return Math.max(0, finalScore);
    }

    getPerformanceGrade() {
        const accuracy = this.getAccuracy();
        const finalScore = this.calculateFinalScore();
        
        if (this.perfectGame && accuracy === 100) return 'S';
        if (accuracy >= 95 && finalScore >= 1500) return 'A+';
        if (accuracy >= 90 && finalScore >= 1200) return 'A';
        if (accuracy >= 85 && finalScore >= 1000) return 'B+';
        if (accuracy >= 80 && finalScore >= 800) return 'B';
        if (accuracy >= 70 && finalScore >= 600) return 'C+';
        if (accuracy >= 60 && finalScore >= 400) return 'C';
        if (accuracy >= 50) return 'D';
        return 'F';
    }

    getStats() {
        return {
            score: this.score,
            finalScore: this.calculateFinalScore(),
            accuracy: this.getAccuracy(),
            attempts: this.attempts,
            correctAttempts: this.correctAttempts,
            maxStreak: this.maxStreak,
            perfectGame: this.perfectGame,
            grade: this.getPerformanceGrade()
        };
    }
}

class Leaderboard {
    constructor() {
        this.storageKey = 'ocean-escape-leaderboard';
        this.maxEntries = 10;
    }

    getLeaderboard(gameType = null) {
        const data = localStorage.getItem(this.storageKey);
        const leaderboard = data ? JSON.parse(data) : {};
        
        if (gameType) {
            return leaderboard[gameType] || [];
        }
        
        return leaderboard;
    }

    addScore(gameType, playerData) {
        const leaderboard = this.getLeaderboard();
        
        if (!leaderboard[gameType]) {
            leaderboard[gameType] = [];
        }
        
        const entry = {
            ...playerData,
            timestamp: Date.now(),
            date: new Date().toLocaleDateString()
        };
        
        leaderboard[gameType].push(entry);
        
        // Sort by final score (descending), then by time (ascending)
        leaderboard[gameType].sort((a, b) => {
            if (b.finalScore !== a.finalScore) {
                return b.finalScore - a.finalScore;
            }
            return a.timeUsed - b.timeUsed;
        });
        
        // Keep only top entries
        leaderboard[gameType] = leaderboard[gameType].slice(0, this.maxEntries);
        
        localStorage.setItem(this.storageKey, JSON.stringify(leaderboard));
        
        // Return rank (1-based)
        return leaderboard[gameType].findIndex(entry => 
            entry.timestamp === playerData.timestamp) + 1;
    }

    getPersonalBest(gameType) {
        const gameLeaderboard = this.getLeaderboard(gameType);
        return gameLeaderboard.length > 0 ? gameLeaderboard[0] : null;
    }

    clearLeaderboard(gameType = null) {
        if (gameType) {
            const leaderboard = this.getLeaderboard();
            delete leaderboard[gameType];
            localStorage.setItem(this.storageKey, JSON.stringify(leaderboard));
        } else {
            localStorage.removeItem(this.storageKey);
        }
    }

    getOverallStats() {
        const leaderboard = this.getLeaderboard();
        const stats = {
            totalGamesPlayed: 0,
            averageScore: 0,
            bestGame: null,
            gameStats: {}
        };
        
        let totalScore = 0;
        let allEntries = [];
        
        Object.entries(leaderboard).forEach(([gameType, entries]) => {
            stats.gameStats[gameType] = {
                gamesPlayed: entries.length,
                bestScore: entries.length > 0 ? entries[0].finalScore : 0,
                averageScore: entries.length > 0 ? 
                    Math.round(entries.reduce((sum, entry) => sum + entry.finalScore, 0) / entries.length) : 0
            };
            
            stats.totalGamesPlayed += entries.length;
            totalScore += entries.reduce((sum, entry) => sum + entry.finalScore, 0);
            allEntries = allEntries.concat(entries);
        });
        
        stats.averageScore = stats.totalGamesPlayed > 0 ? 
            Math.round(totalScore / stats.totalGamesPlayed) : 0;
        
        // Find best overall performance
        if (allEntries.length > 0) {
            stats.bestGame = allEntries.reduce((best, entry) => 
                entry.finalScore > (best?.finalScore || 0) ? entry : best, null);
        }
        
        return stats;
    }
}

// Utility functions for timer and scoring display
class TimerScoringUI {
    static createTimerDisplay(containerId, label = "Time") {
        const container = document.getElementById(containerId);
        if (!container) return null;
        
        const timerHTML = `
            <div class="timer-display">
                <div class="timer-label">${label}</div>
                <div class="timer-value" id="${containerId}-value">--:--</div>
                <div class="timer-progress">
                    <div class="timer-progress-bar" id="${containerId}-progress"></div>
                </div>
            </div>
        `;
        
        container.innerHTML = timerHTML;
        return document.getElementById(`${containerId}-value`);
    }

    static updateTimerDisplay(containerId, timeRemaining, duration) {
        const valueElement = document.getElementById(`${containerId}-value`);
        const progressElement = document.getElementById(`${containerId}-progress`);
        
        if (valueElement) {
            const minutes = Math.floor(timeRemaining / 60);
            const seconds = timeRemaining % 60;
            valueElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            // Update progress bar
            if (progressElement) {
                const progressPercent = (timeRemaining / duration) * 100;
                progressElement.style.width = `${progressPercent}%`;
                
                // Change color based on remaining time
                if (progressPercent < 20) {
                    progressElement.style.backgroundColor = '#ff4444';
                } else if (progressPercent < 50) {
                    progressElement.style.backgroundColor = '#ffaa00';
                } else {
                    progressElement.style.backgroundColor = '#44ff44';
                }
            }
        }
    }

    static createScoreDisplay(containerId, initialScore = 0) {
        const container = document.getElementById(containerId);
        if (!container) return null;
        
        const scoreHTML = `
            <div class="score-display">
                <div class="score-label">Score</div>
                <div class="score-value" id="${containerId}-value">${initialScore}</div>
                <div class="score-streak" id="${containerId}-streak"></div>
            </div>
        `;
        
        container.innerHTML = scoreHTML;
        return document.getElementById(`${containerId}-value`);
    }

    static updateScoreDisplay(containerId, score, streak = 0) {
        const valueElement = document.getElementById(`${containerId}-value`);
        const streakElement = document.getElementById(`${containerId}-streak`);
        
        if (valueElement) {
            valueElement.textContent = score.toLocaleString();
        }
        
        if (streakElement && streak > 1) {
            streakElement.textContent = `🔥 ${streak}x streak!`;
            streakElement.style.display = 'block';
        } else if (streakElement) {
            streakElement.style.display = 'none';
        }
    }
}

// Export classes for use in other files
window.GameTimer = GameTimer;
window.GameScoring = GameScoring;
window.Leaderboard = Leaderboard;
window.TimerScoringUI = TimerScoringUI;