// Audio Manager for Ocean Escape Game
class AudioManager {
    static instance = null;
    
    constructor() {
        if (AudioManager.instance) {
            return AudioManager.instance;
        }
        
        this.backgroundMusic = null;
        this.successSound = null;
        this.clickSound = null;
        this.isMuted = true; // Start muted by default to comply with browser policies
        this.isInitialized = false;
        this.volume = 0.7;
        this.musicVolume = 0.3;
        this.effectsVolume = 0.5;
        
        // Enhanced sound effect management
        this.soundQueue = [];
        this.currentMinigame = null;
        this.lastSoundTime = 0;
        this.soundCooldown = 100; // Minimum time between sounds in ms
        
        AudioManager.instance = this;
    }

    static init() {
        if (!AudioManager.instance) {
            new AudioManager();
        }
        return AudioManager.instance.initialize();
    }

    static get isMuted() {
        return AudioManager.instance ? AudioManager.instance.isMuted : true;
    }

    static toggleSound() {
        if (AudioManager.instance) {
            return AudioManager.instance.toggleMute();
        }
    }

    static playBackgroundMusic() {
        if (AudioManager.instance) {
            return AudioManager.instance.startBackgroundMusic();
        }
    }

    static stopBackgroundMusic() {
        if (AudioManager.instance) {
            return AudioManager.instance.stopBackground();
        }
    }

    static playSuccess() {
        if (AudioManager.instance) {
            return AudioManager.instance.playSuccessSound();
        }
    }

    static playClick() {
        if (AudioManager.instance) {
            return AudioManager.instance.playClickSound();
        }
    }

    // Enhanced sound effect methods
    static playTurtleRescue() {
        if (AudioManager.instance) {
            return AudioManager.instance.playSuccessSound(1.2, 0.7); // Higher pitch, slightly quieter
        }
    }

    static playPlasticSort() {
        if (AudioManager.instance) {
            return AudioManager.instance.playClickSound(0.8, 0.6); // Lower pitch for plastic sounds
        }
    }

    static playQuizCorrect() {
        if (AudioManager.instance) {
            return AudioManager.instance.playSuccessSound(1.0, 0.8); // Normal pitch, louder
        }
    }

    static playQuizIncorrect() {
        if (AudioManager.instance) {
            return AudioManager.instance.playClickSound(0.6, 0.4); // Low pitch, quiet
        }
    }

    static playMicroplasticAdjust() {
        if (AudioManager.instance) {
            return AudioManager.instance.playClickSound(1.1, 0.3); // Subtle tech sound
        }
    }

    static playAchievement() {
        if (AudioManager.instance) {
            return AudioManager.instance.playAchievementSound();
        }
    }

    static setMinigameContext(minigame) {
        if (AudioManager.instance) {
            AudioManager.instance.currentMinigame = minigame;
        }
    }

    static setVolume(volume) {
        if (AudioManager.instance) {
            return AudioManager.instance.setMasterVolume(volume);
        }
    }

    static resetMusicSettings() {
        if (AudioManager.instance) {
            return AudioManager.instance.resetMusicSettings();
        }
    }

    static adjustMusicForMinigame(gameType) {
        if (AudioManager.instance) {
            return AudioManager.instance.adjustMusicForMinigame(gameType);
        }
    }

    initialize() {
        try {
            // Load audio elements
            this.backgroundMusic = document.getElementById('background-music');
            this.successSound = document.getElementById('success-sound');
            this.clickSound = document.getElementById('click-sound');

            if (!this.backgroundMusic || !this.successSound || !this.clickSound) {
                console.warn('Some audio elements not found in DOM');
                return false;
            }

            // Set initial volumes
            this.backgroundMusic.volume = this.musicVolume;
            this.successSound.volume = this.effectsVolume;
            this.clickSound.volume = this.effectsVolume;

            // Configure background music
            this.backgroundMusic.loop = true;
            this.backgroundMusic.preload = 'auto';

            // Configure sound effects
            this.successSound.preload = 'auto';
            this.clickSound.preload = 'auto';

            // Load settings from storage
            this.loadAudioSettings();

            // Add event listeners for error handling
            this.setupErrorHandling();

            this.isInitialized = true;
            console.log('Audio Manager initialized successfully');
            return true;

        } catch (error) {
            console.warn('Failed to initialize Audio Manager:', error);
            return false;
        }
    }

    setupErrorHandling() {
        const audioElements = [this.backgroundMusic, this.successSound, this.clickSound];
        
        audioElements.forEach((audio, index) => {
            if (audio) {
                audio.addEventListener('error', (e) => {
                    console.warn(`Audio error for element ${index}:`, e);
                });

                audio.addEventListener('canplaythrough', () => {
                    console.log(`Audio element ${index} loaded successfully`);
                });
            }
        });
    }

    toggleMute() {
        this.isMuted = !this.isMuted;
        
        if (this.isMuted) {
            this.pauseAll();
        }
        
        this.saveAudioSettings();
        console.log(`Audio ${this.isMuted ? 'muted' : 'unmuted'}`);
        return this.isMuted;
    }

    startBackgroundMusic() {
        if (!this.isInitialized || this.isMuted || !this.backgroundMusic) {
            return false;
        }

        try {
            // Reset to beginning if already played
            this.backgroundMusic.currentTime = 0;
            
            const playPromise = this.backgroundMusic.play();
            
            if (playPromise !== undefined) {
                playPromise
                    .then(() => {
                        console.log('Background music started successfully');
                    })
                    .catch(error => {
                        console.log('Background music autoplay prevented:', error);
                        // This is normal behavior in many browsers
                    });
            }
            
            return true;
        } catch (error) {
            console.warn('Failed to start background music:', error);
            return false;
        }
    }

    stopBackground() {
        if (this.backgroundMusic) {
            try {
                this.backgroundMusic.pause();
                this.backgroundMusic.currentTime = 0;
                console.log('Background music stopped');
                return true;
            } catch (error) {
                console.warn('Failed to stop background music:', error);
                return false;
            }
        }
        return false;
    }

    playSuccessSound(pitchRate = 1.0, volumeMultiplier = 1.0) {
        if (!this.isInitialized || this.isMuted || !this.successSound) {
            return false;
        }

        // Throttle rapid sound effects
        const now = Date.now();
        if (now - this.lastSoundTime < this.soundCooldown) {
            return false;
        }
        this.lastSoundTime = now;

        try {
            // Clone the audio to allow overlapping sounds
            const soundClone = this.successSound.cloneNode();
            soundClone.volume = this.effectsVolume * volumeMultiplier * this.volume;
            soundClone.playbackRate = pitchRate;
            
            const playPromise = soundClone.play();
            
            if (playPromise !== undefined) {
                playPromise
                    .then(() => {
                        console.log(`Success sound played (pitch: ${pitchRate}, volume: ${volumeMultiplier})`);
                    })
                    .catch(error => {
                        console.log('Success sound play prevented:', error);
                    });
            }
            
            return true;
        } catch (error) {
            console.warn('Failed to play success sound:', error);
            return false;
        }
    }

    playClickSound(pitchRate = 1.0, volumeMultiplier = 0.8) {
        if (!this.isInitialized || this.isMuted || !this.clickSound) {
            return false;
        }

        // Throttle rapid click sounds
        const now = Date.now();
        if (now - this.lastSoundTime < this.soundCooldown / 2) { // Shorter cooldown for clicks
            return false;
        }
        this.lastSoundTime = now;

        try {
            // Clone the audio to allow overlapping sounds
            const soundClone = this.clickSound.cloneNode();
            soundClone.volume = this.effectsVolume * volumeMultiplier * this.volume;
            soundClone.playbackRate = pitchRate;
            
            const playPromise = soundClone.play();
            
            if (playPromise !== undefined) {
                playPromise
                    .then(() => {
                        console.log(`Click sound played (pitch: ${pitchRate}, volume: ${volumeMultiplier})`);
                    })
                    .catch(error => {
                        console.log('Click sound play prevented:', error);
                    });
            }
            
            return true;
        } catch (error) {
            console.warn('Failed to play click sound:', error);
            return false;
        }
    }

    setMasterVolume(volume) {
        this.volume = Math.max(0, Math.min(1, volume));
        this.updateVolumes();
        this.saveAudioSettings();
    }

    setMusicVolume(volume) {
        this.musicVolume = Math.max(0, Math.min(1, volume));
        if (this.backgroundMusic) {
            this.backgroundMusic.volume = this.musicVolume * this.volume;
        }
        this.saveAudioSettings();
    }

    setEffectsVolume(volume) {
        this.effectsVolume = Math.max(0, Math.min(1, volume));
        if (this.successSound) {
            this.successSound.volume = this.effectsVolume * this.volume;
        }
        if (this.clickSound) {
            this.clickSound.volume = this.effectsVolume * this.volume;
        }
        this.saveAudioSettings();
    }

    updateVolumes() {
        if (this.backgroundMusic) {
            this.backgroundMusic.volume = this.musicVolume * this.volume;
        }
        if (this.successSound) {
            this.successSound.volume = this.effectsVolume * this.volume;
        }
        if (this.clickSound) {
            this.clickSound.volume = this.effectsVolume * this.volume;
        }
    }

    pauseAll() {
        try {
            if (this.backgroundMusic && !this.backgroundMusic.paused) {
                this.backgroundMusic.pause();
            }
        } catch (error) {
            console.warn('Failed to pause audio:', error);
        }
    }

    resumeAll() {
        if (!this.isMuted) {
            try {
                if (this.backgroundMusic && this.backgroundMusic.paused) {
                    this.backgroundMusic.play().catch(error => {
                        console.log('Background music resume prevented:', error);
                    });
                }
            } catch (error) {
                console.warn('Failed to resume audio:', error);
            }
        }
    }

    saveAudioSettings() {
        try {
            const settings = {
                isMuted: this.isMuted,
                volume: this.volume,
                musicVolume: this.musicVolume,
                effectsVolume: this.effectsVolume
            };
            
            GameStorage.saveSettings({ audio: settings });
        } catch (error) {
            console.warn('Failed to save audio settings:', error);
        }
    }

    loadAudioSettings() {
        try {
            const settings = GameStorage.loadSettings();
            if (settings.audio) {
                this.isMuted = settings.audio.isMuted !== undefined ? settings.audio.isMuted : true;
                this.volume = settings.audio.volume || 0.7;
                this.musicVolume = settings.audio.musicVolume || 0.3;
                this.effectsVolume = settings.audio.effectsVolume || 0.5;
                
                this.updateVolumes();
                console.log('Audio settings loaded from storage');
            }
        } catch (error) {
            console.warn('Failed to load audio settings:', error);
        }
    }

    // Utility method to check if audio is supported
    static isAudioSupported() {
        try {
            return !!(window.Audio || window.webkitAudio || document.createElement('audio').canPlayType);
        } catch (error) {
            return false;
        }
    }

    // Method to preload all audio files
    preloadAudio() {
        const audioElements = [this.backgroundMusic, this.successSound, this.clickSound];
        
        return Promise.all(
            audioElements.map(audio => {
                if (audio) {
                    return new Promise((resolve, reject) => {
                        audio.addEventListener('canplaythrough', resolve, { once: true });
                        audio.addEventListener('error', reject, { once: true });
                        audio.load();
                    });
                }
                return Promise.resolve();
            })
        ).then(() => {
            console.log('All audio files preloaded successfully');
            return true;
        }).catch(error => {
            console.warn('Failed to preload some audio files:', error);
            return false;
        });
    }

    // Enhanced achievement sound with layered effects
    playAchievementSound() {
        if (!this.isInitialized || this.isMuted) {
            return false;
        }

        try {
            // Play a sequence of success sounds for achievement
            this.playSuccessSound(1.0, 1.0); // Base sound
            
            setTimeout(() => {
                this.playSuccessSound(1.2, 0.7); // Higher pitch accent
            }, 200);
            
            setTimeout(() => {
                this.playSuccessSound(0.8, 0.5); // Lower harmonic
            }, 400);
            
            console.log('Achievement sound sequence played');
            return true;
        } catch (error) {
            console.warn('Failed to play achievement sound:', error);
            return false;
        }
    }

    // Contextual background music adjustment
    adjustMusicForMinigame(minigame) {
        if (!this.backgroundMusic || this.isMuted) {
            return;
        }

        try {
            switch (minigame) {
                case 'turtle':
                    this.backgroundMusic.playbackRate = 0.9; // Slower, more peaceful
                    this.backgroundMusic.volume = this.musicVolume * 0.7;
                    break;
                case 'plastic':
                    this.backgroundMusic.playbackRate = 1.1; // Slightly faster for action
                    this.backgroundMusic.volume = this.musicVolume * 0.8;
                    break;
                case 'microplastic':
                    this.backgroundMusic.playbackRate = 0.95; // Scientific, focused
                    this.backgroundMusic.volume = this.musicVolume * 0.6;
                    break;
                default:
                    this.backgroundMusic.playbackRate = 1.0; // Normal speed
                    this.backgroundMusic.volume = this.musicVolume;
            }
        } catch (error) {
            console.warn('Failed to adjust music for minigame:', error);
        }
    }

    // Reset music to normal state
    resetMusicSettings() {
        if (this.backgroundMusic) {
            try {
                this.backgroundMusic.playbackRate = 1.0;
                this.backgroundMusic.volume = this.musicVolume * this.volume;
            } catch (error) {
                console.warn('Failed to reset music settings:', error);
            }
        }
    }

    // Set minigame context for audio adjustments
    setMinigameContext(gameType) {
        this.currentContext = gameType;
    }

    // Get current audio status for debugging
    getStatus() {
        return {
            isInitialized: this.isInitialized,
            isMuted: this.isMuted,
            volume: this.volume,
            musicVolume: this.musicVolume,
            effectsVolume: this.effectsVolume,
            isBackgroundPlaying: this.backgroundMusic ? !this.backgroundMusic.paused : false,
            audioSupported: AudioManager.isAudioSupported()
        };
    }
}

// Handle page visibility changes to pause/resume audio
document.addEventListener('visibilitychange', () => {
    if (AudioManager.instance) {
        if (document.hidden) {
            AudioManager.instance.pauseAll();
        } else {
            AudioManager.instance.resumeAll();
        }
    }
});

// Handle user interaction to enable audio (required by modern browsers)
document.addEventListener('click', () => {
    if (AudioManager.instance && !AudioManager.instance.isMuted) {
        // Try to resume audio context after user interaction
        AudioManager.instance.resumeAll();
    }
}, { once: true });
