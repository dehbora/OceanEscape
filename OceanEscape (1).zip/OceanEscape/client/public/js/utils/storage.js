// Game Storage Utility
class GameStorage {
    static STORAGE_KEY = 'ocean_escape_game_data';
    static VERSION = '1.0';

    static saveProgress(data) {
        try {
            const gameData = {
                version: this.VERSION,
                timestamp: Date.now(),
                ...data
            };
            
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(gameData));
            console.log('Game progress saved successfully');
            return true;
        } catch (error) {
            console.warn('Failed to save game progress:', error);
            return false;
        }
    }

    static loadProgress() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            if (!data) {
                return null;
            }

            const gameData = JSON.parse(data);
            
            // Check version compatibility
            if (gameData.version !== this.VERSION) {
                console.warn('Game data version mismatch, starting fresh');
                this.clearProgress();
                return null;
            }

            console.log('Game progress loaded successfully');
            return gameData;
        } catch (error) {
            console.warn('Failed to load game progress:', error);
            return null;
        }
    }

    static clearProgress() {
        try {
            localStorage.removeItem(this.STORAGE_KEY);
            console.log('Game progress cleared');
            return true;
        } catch (error) {
            console.warn('Failed to clear game progress:', error);
            return false;
        }
    }

    static saveSettings(settings) {
        try {
            const currentData = this.loadProgress() || {};
            currentData.settings = {
                ...currentData.settings,
                ...settings
            };
            
            return this.saveProgress(currentData);
        } catch (error) {
            console.warn('Failed to save settings:', error);
            return false;
        }
    }

    static loadSettings() {
        try {
            const data = this.loadProgress();
            return data ? data.settings || {} : {};
        } catch (error) {
            console.warn('Failed to load settings:', error);
            return {};
        }
    }

    static saveGameStatistics(stats) {
        try {
            const currentData = this.loadProgress() || {};
            currentData.statistics = {
                ...currentData.statistics,
                ...stats,
                lastPlayed: Date.now()
            };
            
            return this.saveProgress(currentData);
        } catch (error) {
            console.warn('Failed to save statistics:', error);
            return false;
        }
    }

    static loadGameStatistics() {
        try {
            const data = this.loadProgress();
            return data ? data.statistics || {} : {};
        } catch (error) {
            console.warn('Failed to load statistics:', error);
            return {};
        }
    }

    static saveMinigameScore(gameName, score, timeSpent = 0) {
        try {
            const currentData = this.loadProgress() || {};
            
            if (!currentData.minigameScores) {
                currentData.minigameScores = {};
            }
            
            if (!currentData.minigameScores[gameName]) {
                currentData.minigameScores[gameName] = {
                    bestScore: 0,
                    totalPlays: 0,
                    totalTimeSpent: 0,
                    averageScore: 0,
                    scores: []
                };
            }
            
            const gameData = currentData.minigameScores[gameName];
            
            // Update statistics
            gameData.totalPlays++;
            gameData.totalTimeSpent += timeSpent;
            gameData.scores.push({
                score: score,
                timestamp: Date.now(),
                timeSpent: timeSpent
            });
            
            // Keep only last 10 scores
            if (gameData.scores.length > 10) {
                gameData.scores = gameData.scores.slice(-10);
            }
            
            // Update best score
            if (score > gameData.bestScore) {
                gameData.bestScore = score;
            }
            
            // Calculate average score
            gameData.averageScore = Math.round(
                gameData.scores.reduce((sum, entry) => sum + entry.score, 0) / gameData.scores.length
            );
            
            return this.saveProgress(currentData);
        } catch (error) {
            console.warn('Failed to save minigame score:', error);
            return false;
        }
    }

    static getMinigameStats(gameName) {
        try {
            const data = this.loadProgress();
            if (data && data.minigameScores && data.minigameScores[gameName]) {
                return data.minigameScores[gameName];
            }
            return null;
        } catch (error) {
            console.warn('Failed to load minigame stats:', error);
            return null;
        }
    }

    static saveAchievement(achievementId, achievementData) {
        try {
            const currentData = this.loadProgress() || {};
            
            if (!currentData.achievements) {
                currentData.achievements = {};
            }
            
            currentData.achievements[achievementId] = {
                ...achievementData,
                unlockedAt: Date.now()
            };
            
            return this.saveProgress(currentData);
        } catch (error) {
            console.warn('Failed to save achievement:', error);
            return false;
        }
    }

    static getAchievements() {
        try {
            const data = this.loadProgress();
            return data ? data.achievements || {} : {};
        } catch (error) {
            console.warn('Failed to load achievements:', error);
            return {};
        }
    }

    static isStorageAvailable() {
        try {
            const test = '__storage_test__';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (error) {
            return false;
        }
    }

    static getStorageUsage() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            const sizeInBytes = data ? new Blob([data]).size : 0;
            const sizeInKB = Math.round(sizeInBytes / 1024 * 100) / 100;
            
            return {
                bytes: sizeInBytes,
                kilobytes: sizeInKB,
                megabytes: Math.round(sizeInKB / 1024 * 100) / 100
            };
        } catch (error) {
            console.warn('Failed to calculate storage usage:', error);
            return { bytes: 0, kilobytes: 0, megabytes: 0 };
        }
    }

    static exportData() {
        try {
            const data = this.loadProgress();
            if (!data) {
                return null;
            }
            
            const exportData = {
                ...data,
                exportedAt: Date.now(),
                gameVersion: this.VERSION
            };
            
            return JSON.stringify(exportData, null, 2);
        } catch (error) {
            console.warn('Failed to export data:', error);
            return null;
        }
    }

    static importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            
            // Basic validation
            if (!data.version || !data.completedGames) {
                throw new Error('Invalid game data format');
            }
            
            // Check if data is newer than current
            const currentData = this.loadProgress();
            if (currentData && currentData.timestamp > data.timestamp) {
                const proceed = confirm('The imported data is older than your current progress. Continue?');
                if (!proceed) {
                    return false;
                }
            }
            
            return this.saveProgress(data);
        } catch (error) {
            console.warn('Failed to import data:', error);
            alert('Failed to import game data. Please check the file format.');
            return false;
        }
    }

    static migrateLegacyData() {
        try {
            // Check for old storage keys and migrate if needed
            const legacyKeys = ['ocean_game_progress', 'escape_room_data'];
            
            for (const key of legacyKeys) {
                const legacyData = localStorage.getItem(key);
                if (legacyData) {
                    console.log(`Migrating legacy data from ${key}`);
                    const data = JSON.parse(legacyData);
                    
                    // Convert legacy format to new format
                    const migratedData = {
                        version: this.VERSION,
                        completedGames: data.completed || [],
                        timestamp: data.timestamp || Date.now(),
                        settings: data.settings || {},
                        migrated: true,
                        originalKey: key
                    };
                    
                    this.saveProgress(migratedData);
                    localStorage.removeItem(key); // Clean up old data
                    return true;
                }
            }
            
            return false;
        } catch (error) {
            console.warn('Failed to migrate legacy data:', error);
            return false;
        }
    }

    static debugInfo() {
        const data = this.loadProgress();
        const usage = this.getStorageUsage();
        const isAvailable = this.isStorageAvailable();
        
        return {
            storageAvailable: isAvailable,
            hasData: !!data,
            dataTimestamp: data ? new Date(data.timestamp).toLocaleString() : null,
            completedGames: data ? data.completedGames : [],
            storageUsage: usage,
            version: this.VERSION
        };
    }
}

// Auto-migrate legacy data on load
document.addEventListener('DOMContentLoaded', () => {
    if (GameStorage.isStorageAvailable()) {
        GameStorage.migrateLegacyData();
    } else {
        console.warn('Local storage is not available. Game progress will not be saved.');
    }
});
